// Purrfect-pal-studio.Ravn.SafariExtension/Resources/background.js
// Hybrid WebExtension Background Script for Ravn.
// Supports both standard Chromium HTTP communication and Safari Native Messaging!
"use strict";

const RAVN_HOST = "http://127.0.0.1:6543";

const DOWNLOAD_EXTS = new Set([
  "zip","rar","7z","tar","gz","bz2","xz","iso","dmg","pkg",
  "mp4","mkv","avi","mov","m4v","wmv","webm","flv",
  "mp3","flac","wav","aac","m4a","ogg","opus","wma",
  "pdf","epub","djvu","doc","docx","xls","xlsx","ppt","pptx",
  "exe","msi","deb","rpm","apk","ipa","appimage",
  "torrent"
]);

const STREAM_MIME_PATTERNS = [
  "video/", "audio/", "application/x-mpegurl",
  "application/dash+xml", "application/vnd.apple.mpegurl"
];
const STREAM_EXT_PATTERNS = [".m3u8", ".mpd"];

// Valid quality values — must match YTDLQuality.rawValue in Swift exactly.
const VALID_QUALITIES = new Set(["best", "2160p", "1080p", "720p", "480p", "audio"]);

// ─── Settings ─────────────────────────────────────────────────────────────────
let settings = { enabled: true, interceptAll: false, streamGrab: true, blobExtract: true };
chrome.storage.sync.get(["settings"], r => {
  if (r.settings) settings = { ...settings, ...r.settings };
});
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "sync" && changes.settings) {
    settings = { ...settings, ...changes.settings.newValue };
  }
});

// ─── Video tab registry ───────────────────────────────────────────────────────
const videoTabs = new Map(); // tabId → { platform, url, title, icon }

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === "loading") {
    videoTabs.delete(tabId);
    chrome.action.setBadgeText({ text: "", tabId }).catch(() => {});
  }
});
chrome.tabs.onRemoved.addListener(tabId => videoTabs.delete(tabId));

// ─── Blob dedup guard ─────────────────────────────────────────────────────────
let _skipNextBlobDownload = false;

// ─── Stream URL deduplication ─────────────────────────────────────────────────
const _seenStreams = new Map();  // url → timestamp
const STREAM_DEDUP_TTL = 300_000; // ms

function isStreamSeen(url) {
  const now = Date.now();
  for (const [k, t] of _seenStreams) {
    if (now - t > STREAM_DEDUP_TTL) _seenStreams.delete(k);
  }
  
  let key = url;
  try {
    const u = new URL(url);
    const id = u.searchParams.get("id") || u.searchParams.get("docid");
    const itag = u.searchParams.get("itag");
    if (id || itag) {
      key = "yt:" + (id || "noid") + ":" + (itag || "noitag");
    } else {
      key = url;
    }
  } catch (_) {}
  
  if (_seenStreams.has(key)) return true;
  _seenStreams.set(key, now);
  return false;
}

// Helper to clear the stream list in the Mac app
async function clearStreamsInApp() {
  _seenStreams.clear();
  try {
    await callRavnAPI("/streams/clear", "POST");
  } catch (_) {}
}

// ─── Platform Detection ───────────────────────────────────────────────────────
const isSafari = () => {
  const hasSafariScheme = (typeof chrome !== "undefined" && chrome.runtime?.getURL && chrome.runtime.getURL("").startsWith("safari-web-extension://")) ||
                          (typeof browser !== "undefined" && browser.runtime?.getURL && browser.runtime.getURL("").startsWith("safari-web-extension://"));
  if (hasSafariScheme) return true;

  return typeof browser !== "undefined" && 
         (navigator.userAgent.includes("Safari") && 
          !navigator.userAgent.includes("Chrome") && 
          !navigator.userAgent.includes("Edg"));
};

// ─── Safari Native Messaging Helper ──────────────────────────────────────────
async function sendSafariNativeMessage(payload) {
  const extAPI = typeof browser !== "undefined" ? browser : chrome;
  if (!extAPI?.runtime?.sendNativeMessage) {
    throw new Error("sendNativeMessage not available in this runtime");
  }

  return new Promise((resolve, reject) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        reject(new Error("Safari native messaging timeout (1500ms)"));
      }
    }, 1500);

    const finish = (err, val) => {
      if (!settled) {
        settled = true;
        clearTimeout(timer);
        if (err) reject(err);
        else resolve(val || { ok: true });
      }
    };

    try {
      // In Safari Web Extensions, sendNativeMessage("", payload) routes directly to SafariWebExtensionHandler
      const resPromise = extAPI.runtime.sendNativeMessage("", payload, (response) => {
        const err = extAPI.runtime.lastError;
        if (err) finish(new Error(err.message || String(err)));
        else if (response && response.error) finish(new Error(response.error));
        else finish(null, response);
      });

      if (resPromise && typeof resPromise.then === "function") {
        resPromise
          .then(res => {
            if (res && res.error) finish(new Error(res.error));
            else finish(null, res);
          })
          .catch(err => finish(err));
      }
    } catch (e) {
      try {
        const p = extAPI.runtime.sendNativeMessage("", payload);
        if (p && typeof p.then === "function") {
          p.then(res => {
            if (res && res.error) finish(new Error(res.error));
            else finish(null, res);
          }).catch(err => finish(err));
        } else {
          finish(e);
        }
      } catch (innerErr) {
        finish(innerErr);
      }
    }
  });
}

// ─── Core loopback proxy (Direct HTTP to 127.0.0.1:6543 with Native Host Fallback) ─
async function callRavnAPI(path, method, body = null) {
  // 1. If Safari, prioritize Native Messaging to SafariWebExtensionHandler
  if (isSafari()) {
    const actionMap = {
      "/ping": "ping",
      "/download": "download",
      "/batch": "batch",
      "/stream": "stream",
      "/streams/clear": "clearStreams",
      "/grab": "grab",
      "/ytdlp/check": "checkYtdlp",
      "/status": "status",
      "/download/refresh": "refreshLink"
    };
    const action = actionMap[path];
    if (action) {
      try {
        const payload = { action, ...(body || {}) };
        const nativeRes = await sendSafariNativeMessage(payload);
        if (nativeRes) return nativeRes;
      } catch (nativeErr) {
        console.warn(`[Ravn Safari] Native message for ${path} error:`, nativeErr);
      }
    }
  }

  // 2. Direct local HTTP fetch to LocalServer on 127.0.0.1:6543 (Chrome or Safari HTTP fallback)
  try {
    let signal;
    if (AbortSignal.timeout) {
      signal = AbortSignal.timeout(1800);
    } else {
      const controller = new AbortController();
      setTimeout(() => controller.abort(), 1800);
      signal = controller.signal;
    }

    const options = {
      method,
      headers: { "Content-Type": "application/json" },
      signal
    };
    if (body) {
      options.body = JSON.stringify(body);
    }

    const res = await fetch(RAVN_HOST + path, options);
    if (res.ok) {
      if (res.status === 204 || res.headers.get("content-length") === "0") {
        return { ok: true };
      }
      try {
        return await res.json();
      } catch (_) {
        return { ok: true };
      }
    }
  } catch (httpErr) {
    if (!isSafari()) {
      console.warn(`[Ravn Chrome] HTTP communication failed for ${path}:`, httpErr);
    }
  }

  throw new Error(`Failed to communicate with Ravn on ${path}`);
}

async function trySendHTTP(path, body) {
  try {
    await callRavnAPI(path, "POST", body);
    return true;
  } catch (err) {
    console.error(`[Ravn] trySendHTTP failed for path ${path}:`, err);
    return false;
  }
}

async function pingRavn() {
  try {
    await callRavnAPI("/ping", "GET");
    return true;
  } catch (_) { return false; }
}

async function checkYTDLP() {
  try {
    return await callRavnAPI("/ytdlp/check", "GET");
  } catch (_) { return { available: false }; }
}

async function getStatus() {
  try {
    return await callRavnAPI("/status", "GET");
  } catch (_) { return { downloads: [], total: 0 }; }
}

// ─── Download Interception ────────────────────────────────────────────────────
if (typeof chrome !== "undefined" && chrome.downloads && chrome.downloads.onCreated) {
  chrome.downloads.onCreated.addListener(async (item) => {
    if (!settings.enabled) return;

    // data: URLs are ours (from blob extraction) — always pass through
    if (item.url.startsWith("data:")) return;

    // blob: URLs — attempt in-page extraction
    if (item.url.startsWith("blob:")) {
      if (_skipNextBlobDownload) { _skipNextBlobDownload = false; return; }
      if (!settings.blobExtract) return;

      try { await chrome.downloads.cancel(item.id); } catch (_) {}
      try { await chrome.downloads.erase({ id: item.id }); } catch (_) {}

      const tabId = await resolveTabForBlob(item);
      if (tabId !== null) {
        extractBlob(tabId, item.url, item.filename || "");
      } else {
        console.warn("[Ravn] blob: URL detected but no tab found to extract from.");
      }
      return;
    }

    // Regular URL — check extension
    let ext = "";
    try { ext = new URL(item.url).pathname.split(".").pop().toLowerCase(); }
    catch (_) { return; }

    if (!DOWNLOAD_EXTS.has(ext) && !settings.interceptAll) return;

    try { await chrome.downloads.cancel(item.id); } catch (_) {}
    try { await chrome.downloads.erase({ id: item.id }); } catch (_) {}

    sendToRavn(item.url, item.filename || "");
  });
}

// ─── Blob Helpers ─────────────────────────────────────────────────────────────
async function resolveTabForBlob(item) {
  if (item.initiatingFrameUrl) {
    try {
      const origin = new URL(item.initiatingFrameUrl).origin;
      const tabs = await chrome.tabs.query({});
      for (const tab of tabs) {
        try {
          if (tab.url && new URL(tab.url).origin === origin) return tab.id;
        } catch (_) {}
      }
    } catch (_) {}
  }
  const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  return active?.id ?? null;
}

async function extractBlob(tabId, blobUrl, suggestedFilename) {
  let res;
  try {
    res = await chrome.tabs.sendMessage(tabId, {
      action:   "fetchBlob",
      url:      blobUrl,
      filename: suggestedFilename
    });
  } catch (err) {
    console.error("[Ravn] fetchBlob message failed:", err);
    return;
  }

  if (res?.error) { console.error("[Ravn] blob extraction error:", res.error); return; }
  if (!res?.dataUrl) { console.warn("[Ravn] content returned no dataUrl"); return; }

  const filename = res.filename || suggestedFilename || "download";
  _skipNextBlobDownload = true;

  try {
    if (isSafari()) {
      sendToRavn(res.dataUrl, sanitizeFilename(filename));
    } else if (typeof chrome.downloads !== "undefined") {
      await chrome.downloads.download({
        url:      res.dataUrl,
        filename: sanitizeFilename(filename),
        saveAs:   false
      });
    } else {
      console.warn("[Ravn] chrome.downloads.download is not supported in this browser.");
    }
  } catch (err) {
    _skipNextBlobDownload = false;
    console.error("[Ravn] chrome.downloads.download (blob):", err);
  }
}

function sanitizeFilename(name) {
  return name.replace(/[/\\:*?"<>|\x00]/g, "_").trim() || "download";
}

// ─── Context Menu ─────────────────────────────────────────────────────────────
function setupContextMenus() {
  if (typeof chrome === "undefined" || !chrome.contextMenus) return;
  try {
    chrome.contextMenus.removeAll(() => {
      if (chrome.runtime.lastError) { /* ignore cleanup error */ }
      try {
        chrome.contextMenus.create({ id: "ravn-download-link",  title: "Download with Ravn",               contexts: ["link"]  });
        chrome.contextMenus.create({ id: "ravn-download-image", title: "Download Image with Ravn",         contexts: ["image"] });
        chrome.contextMenus.create({ id: "ravn-download-video", title: "Download Video with Ravn",         contexts: ["video"] });
        chrome.contextMenus.create({ id: "ravn-grab-video",     title: "Grab Video with Ravn (yt-dlp)",    contexts: ["page", "link"] });
        chrome.contextMenus.create({ id: "ravn-scan-page",      title: "Scan page for downloadable links", contexts: ["page"] });
      } catch (err) {
        console.warn("[Ravn ContextMenu] Setup warning:", err);
      }
    });
  } catch (e) {
    console.warn("[Ravn ContextMenu] removeAll warning:", e);
  }
}

chrome.runtime.onInstalled.addListener(setupContextMenus);
chrome.runtime.onStartup.addListener(setupContextMenus);

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  try {
    switch (info.menuItemId) {
      case "ravn-download-link": {
        const targetUrl = info.linkUrl || info.pageUrl || tab?.url;
        if (targetUrl) await sendToRavn(targetUrl, "", "", tab?.url || "");
        break;
      }
      case "ravn-download-image": {
        const srcUrl = info.srcUrl || "";
        if (srcUrl) await sendToRavn(srcUrl, "", "", tab?.url || "");
        break;
      }
      case "ravn-download-video": {
        const srcUrl = info.srcUrl || info.linkUrl || "";
        if (srcUrl) await sendToRavn(srcUrl, "", "", tab?.url || "");
        break;
      }
      case "ravn-grab-video": {
        const targetUrl = info.linkUrl || info.pageUrl || tab?.url || "";
        if (targetUrl) await grabVideo(targetUrl, tab?.title || "", "best");
        break;
      }
      case "ravn-scan-page": {
        if (tab?.id && tab.id > 0) {
          chrome.tabs.sendMessage(tab.id, { action: "scanPage" }, (res) => {
            if (chrome.runtime.lastError) {
              console.warn("[Ravn] scanPage warning:", chrome.runtime.lastError.message);
              return;
            }
            if (res && res.urls && Array.isArray(res.urls) && res.urls.length > 0) {
              sendBatch(res.urls);
            }
          });
        }
        break;
      }
    }
  } catch (err) {
    console.error("[Ravn ContextMenu Error]", err);
  }
});

// ─── Stream Sniffing via webRequest (Chrome/Firefox only) ───────────────────
// Safari MV3 does NOT support chrome.webRequest — the API is undefined.
// On Safari, streams are detected by the page-context XHR/fetch hook injected
// by content.js, which sends a `streamDetectedByPage` runtime message instead.
if (typeof chrome.webRequest !== "undefined" && chrome.webRequest.onCompleted) {
chrome.webRequest.onCompleted.addListener(
  (details) => {
    if (!settings.streamGrab)                return;
    if (!details.tabId || details.tabId < 0) return;

    const mime = details.responseHeaders
      ?.find(h => h.name.toLowerCase() === "content-type")?.value ?? "";
    const url = details.url;

    let pathname = "";
    try { pathname = new URL(url).pathname.toLowerCase(); } catch (_) { return; }

    const urlLower = url.toLowerCase();
    
    // Ignore internal browser/extension resources
    if (urlLower.startsWith("chrome") || urlLower.startsWith("moz") || urlLower.startsWith("safari") || urlLower.startsWith("about") || urlLower.startsWith("file")) {
      return;
    }
    
    // Ignore small interface sound assets (e.g. notifications)
    const soundKeywords = ["notification", "chime", "sound", "click", "ping", "ding", "beep", "bell", "ring", "alert", "tone", "incoming", "message", "chat"];
    const isAudioFile = pathname.endsWith(".mp3") || pathname.endsWith(".wav") || pathname.endsWith(".ogg") || pathname.endsWith(".m4a") || pathname.endsWith(".aac");
    if (isAudioFile && soundKeywords.some(kw => urlLower.includes(kw))) {
      return;
    }

    const adKeywords = [
      "googleads", "doubleclick", "googlesyndication", "pagead", "adservices", "pubads",
      "/ads/", "/ad/", "ad-system", "adserver", "adsystem", "adskeeper", "adsterra",
      "adform", "adroll", "adnxs", "analytics", "telemetry", "amplitude", "mixpanel",
      "segment.io", "hotjar", "crazyegg", "tracking", "/track/", "amazon-adsystem",
      "taboola", "outbrain", "criteo", "popads", "propellerads", "exoclick", "yieldmanager",
      "rubiconproject", "openx", "adtech", "mgid", "revcontent", "adcolony", "vungle",
      "applovin", "chartboost", "ironsrc", "video-ad", "ad_video", "vast", "vpaid",
      "ima3", "/adunit", "advertising", "sponsor", "partnerads", "affiliate", "adwrapper",
      "prebid", "bidder", "stat", "pixel", "beacon", "preroll", "midroll", "postroll",
      "sponsored", "advertisement", "ad_pod", "_ad_", "-ad-"
    ];
    const isAd = adKeywords.some(keyword => urlLower.includes(keyword)) ||
                 urlLower.includes("/ad/") ||
                 urlLower.includes("/ads/") ||
                 urlLower.includes("pltype=ad") ||
                 urlLower.includes("adformat=") ||
                 urlLower.includes("madv=") ||
                 urlLower.includes("ptracking") ||
                 urlLower.includes("ad_type=");

    const isStream =
      !isAd && (
        STREAM_MIME_PATTERNS.some(p => mime.toLowerCase().includes(p)) ||
        STREAM_EXT_PATTERNS.some(e => pathname.endsWith(e))
      );

    if (!isStream) return;

    if (isStreamSeen(url)) return;

    chrome.tabs.get(details.tabId, tab => {
      if (chrome.runtime.lastError) return;
      
      let title = (tab?.title ?? "")
        .replace(/^\(\d+\)\s+/, "")
        .replace(/\s*-\s*YouTube$/, "")
        .trim();
        
      registerStream(url, title, mime, tab?.url || "");
    });
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);
} // end webRequest guard

// ─── Messages ─────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.action) {

    case "sendURL":
      sendToRavn(msg.url, msg.filename ?? "", msg.cookies ?? "", msg.referer ?? "")
        .then(() => sendResponse({ ok: true }))
        .catch(err => {
          console.error("[Ravn] sendToRavn error:", err);
          sendResponse({ ok: false, error: err?.message });
        });
      return true;

    case "refreshDownload":
      (async () => {
        let cookies = "", referer = "";
        try {
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          const cookieUrl = (tab?.url && !tab.url.startsWith("chrome")) ? tab.url : msg.url;
          const jar = await chrome.cookies.getAll({ url: cookieUrl });
          cookies = jar.map(c => `${c.name}=${c.value}`).join("; ");
          if (tab?.url && !tab.url.startsWith("chrome")) referer = tab.url;
        } catch (_) {}

        try {
          const res = await callRavnAPI("/download/refresh", "POST", {
            id: msg.id,
            originalUrl: msg.originalUrl,
            url: msg.url,
            cookies: msg.cookies || cookies,
            referer: msg.referer || referer
          });
          sendResponse(res);
        } catch (err) {
          sendResponse({ error: err.message });
        }
      })();
      return true;

    case "sendBatch":
      sendBatch(msg.urls ?? []);
      sendResponse({ ok: true });
      break;

    case "ping":
      pingRavn().then(ok => sendResponse({ ok }));
      return true;

    case "status":
      getStatus().then(status => sendResponse(status));
      return true;

    case "updateSettings":
      settings = { ...settings, ...msg.settings };
      chrome.storage.sync.set({ settings });
      sendResponse({ ok: true });
      break;

    case "videoPageDetected":
      if (sender.tab?.id) {
        videoTabs.set(sender.tab.id, {
          platform: msg.platform,
          url:      msg.url,
          title:    msg.title,
          icon:     msg.icon
        });
        chrome.action.setBadgeText({ text: "▶", tabId: sender.tab.id }).catch(() => {});
        chrome.action.setBadgeBackgroundColor({ color: "#6366f1", tabId: sender.tab.id }).catch(() => {});
        
        _seenStreams.clear();
      }
      sendResponse({ ok: true });
      break;

    case "getVideoInfo": {
      const tabId = msg.tabId ?? sender.tab?.id;
      const info  = tabId ? (videoTabs.get(tabId) ?? null) : null;
      sendResponse({ info });
      break;
    }

    case "grabVideo":
      grabVideo(msg.url, msg.title ?? "", msg.quality ?? "best")
        .then(ok => sendResponse({ ok }));
      return true;

    case "checkYTDLP":
      checkYTDLP().then(result => sendResponse(result));
      return true;

    // ── Safari stream grabber path ────────────────────────────────────────
    // Sent by the page-context XHR/fetch hook in content.js when webRequest
    // is unavailable (Safari MV3). We de-duplicate and forward to the app.
    case "streamDetectedByPage": {
      if (!settings.streamGrab) break;
      const streamUrl  = msg.url;
      const streamMime = msg.mime || "application/x-mpegurl";
      const streamTitle = msg.title || "";
      const streamPage  = msg.pageUrl || "";
      if (!streamUrl) break;
      if (isStreamSeen(streamUrl)) { sendResponse({ ok: true }); break; }
      // Apply the same ad-filter as the webRequest path
      const urlLowerSB = streamUrl.toLowerCase();
      const adKeywordsSB = [
        "googleads","doubleclick","googlesyndication","pagead","adservices","pubads",
        "/ads/","/ad/","ad-system","adserver","vast","vpaid","ima3","preroll",
        "midroll","postroll","advertisement","ad_pod","_ad_","-ad-"
      ];
      const isAdSB = adKeywordsSB.some(kw => urlLowerSB.includes(kw));
      if (!isAdSB) {
        registerStream(streamUrl, streamTitle, streamMime, streamPage);
      }
      sendResponse({ ok: true });
      break;
    }
  }
});

// ─── Cross-Browser Cookie Extractor ──────────────────────────────────────────
async function getCookiesForUrl(targetUrl) {
  if (!targetUrl) return "";
  const extAPI = typeof browser !== "undefined" ? browser : chrome;
  const cookieAPI = extAPI?.cookies || (typeof chrome !== "undefined" ? chrome.cookies : null);
  if (!cookieAPI || !cookieAPI.getAll) return "";

  try {
    const jar = await new Promise((resolve) => {
      try {
        const p = cookieAPI.getAll({ url: targetUrl }, (res) => resolve(res || []));
        if (p && typeof p.then === "function") p.then(resolve).catch(() => resolve([]));
      } catch (_) { resolve([]); }
    });

    if (jar && jar.length > 0) {
      return jar.map(c => `${c.name}=${c.value}`).join("; ");
    }
  } catch (_) {}

  // Fallback to origin
  try {
    const origin = new URL(targetUrl).origin;
    const jar = await new Promise((resolve) => {
      try {
        const p = cookieAPI.getAll({ url: origin }, (res) => resolve(res || []));
        if (p && typeof p.then === "function") p.then(resolve).catch(() => resolve([]));
      } catch (_) { resolve([]); }
    });
    if (jar && jar.length > 0) {
      return jar.map(c => `${c.name}=${c.value}`).join("; ");
    }
  } catch (_) {}

  return "";
}

// ─── Ravn Communication Helpers ───────────────────────────────────────────────
async function sendToRavn(url, filename = "", explicitCookies = "", explicitReferer = "") {
  if (!url) return;

  let cookies = explicitCookies || "", referer = explicitReferer || "";
  try {
    const extAPI = typeof browser !== "undefined" ? browser : chrome;
    let tabs = [];
    if (extAPI?.tabs?.query) {
      tabs = await new Promise(r => {
        try {
          const p = extAPI.tabs.query({ active: true, currentWindow: true }, res => r(res || []));
          if (p && typeof p.then === "function") p.then(r).catch(() => r([]));
        } catch (_) { r([]); }
      });
    }
    const tab = tabs?.[0];
    const cookieUrl = (tab?.url && !tab.url.startsWith("chrome") && !tab.url.startsWith("safari-web-extension")) ? tab.url : url;

    const jarCookies = await getCookiesForUrl(cookieUrl);
    if (jarCookies) {
      cookies = cookies ? `${cookies}; ${jarCookies}` : jarCookies;
    }
    if (url && cookieUrl !== url) {
      const urlCookies = await getCookiesForUrl(url);
      if (urlCookies) {
        cookies = cookies ? `${cookies}; ${urlCookies}` : urlCookies;
      }
    }
    if (!referer && tab?.url && !tab.url.startsWith("chrome") && !tab.url.startsWith("safari-web-extension")) {
      referer = tab.url;
    }
  } catch (_) {}

  // Send download to Ravn LocalServer immediately
  let sent = await trySendHTTP("/download", { url, filename, cookies, referer });
  if (!sent) {
    // Retry once in case service worker or local server was momentarily waking up
    await new Promise(r => setTimeout(r, 200));
    sent = await trySendHTTP("/download", { url, filename, cookies, referer });
  }
  if (!sent) trySendURLScheme(url, filename, cookies, referer);
}

async function sendBatch(urls) {
  if (!urls || urls.length === 0) return;
  let sent = await trySendHTTP("/batch", { urls });
  if (!sent) {
    await new Promise(r => setTimeout(r, 250));
    sent = await trySendHTTP("/batch", { urls });
  }
  if (!sent) {
    const encodedUrls = urls.map(u => encodeURIComponent(u)).join(",");
    triggerSchemeURL(`ravn://batch?urls=${encodedUrls}`);
  }
}

async function registerStream(url, title, mime, pageUrl = "") {
  let cookies = "", referer = "";
  try {
    const extAPI = typeof browser !== "undefined" ? browser : chrome;
    let tabs = [];
    if (extAPI?.tabs?.query) {
      tabs = await new Promise(r => {
        try {
          const p = extAPI.tabs.query({ active: true, currentWindow: true }, res => r(res || []));
          if (p && typeof p.then === "function") p.then(r).catch(() => r([]));
        } catch (_) { r([]); }
      });
    }
    const tab = tabs?.[0];
    if (tab?.url && !tab.url.startsWith("chrome") && !tab.url.startsWith("safari-web-extension")) {
      referer = tab.url;
      cookies = await getCookiesForUrl(tab.url);
    }
  } catch (_) {}

  const finalPageUrl = pageUrl || referer;

  // Intercept if this stream is a fresh link for an expired download
  const refreshed = await checkAndRefreshFailedDownload(url, cookies, finalPageUrl);
  if (refreshed) return;

  await trySendHTTP("/stream", { url, title, mime, pageUrl: finalPageUrl, headers: { Cookie: cookies, Referer: referer } });
}

async function grabVideo(url, title, quality) {
  const safeQuality = VALID_QUALITIES.has(quality) ? quality : "best";

  let cookies = "", referer = "";
  try {
    const extAPI = typeof browser !== "undefined" ? browser : chrome;
    let tabs = [];
    if (extAPI?.tabs?.query) {
      tabs = await new Promise(r => {
        try {
          const p = extAPI.tabs.query({ active: true, currentWindow: true }, res => r(res || []));
          if (p && typeof p.then === "function") p.then(r).catch(() => r([]));
        } catch (_) { r([]); }
      });
    }
    const tab = tabs?.[0];
    if (tab?.url && !tab.url.startsWith("chrome") && !tab.url.startsWith("safari-web-extension")) {
      referer = tab.url;
      cookies = await getCookiesForUrl(tab.url);
    }
  } catch (_) {}

  return trySendHTTP("/grab", { url, title, quality: safeQuality, cookies, referer });
}

function trySendURLScheme(url, filename = "", cookies = "", referer = "") {
  if (!url) return;
  const encoded = encodeURIComponent(url);
  const fn = filename ? `&filename=${encodeURIComponent(filename)}` : "";
  const ck = cookies ? `&cookies=${encodeURIComponent(cookies)}` : "";
  const rf = referer ? `&referer=${encodeURIComponent(referer)}` : "";
  const schemeUrl = `ravn://add?url=${encoded}${fn}${ck}${rf}`;
  triggerSchemeURL(schemeUrl);
}

function triggerSchemeURL(schemeUrl) {
  try {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs?.[0];
      if (tab?.id && tab.url && !tab.url.startsWith("chrome://") && !tab.url.startsWith("edge://") && !tab.url.startsWith("about:") && !tab.url.startsWith("chrome-extension://")) {
        if (typeof chrome.scripting !== "undefined" && chrome.scripting.executeScript) {
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: (sUrl) => {
              try {
                const a = document.createElement("a");
                a.href = sUrl;
                a.style.display = "none";
                document.body.appendChild(a);
                a.click();
                setTimeout(() => { if (a.parentNode) a.parentNode.removeChild(a); }, 500);
              } catch (_) {
                window.location.href = sUrl;
              }
            },
            args: [schemeUrl]
          }).catch(() => {
            openAndCleanSchemeTab(schemeUrl);
          });
          return;
        }
      }
      
      openAndCleanSchemeTab(schemeUrl);
    });
  } catch (_) {
    openAndCleanSchemeTab(schemeUrl);
  }
}

function openAndCleanSchemeTab(schemeUrl) {
  chrome.tabs.create({ url: schemeUrl, active: false }, t => {
    if (t?.id) setTimeout(() => chrome.tabs.remove(t.id).catch(() => {}), 1000);
  });
}

// ─── Auto-Refresh & Expired Link Recovery ─────────────────────────────────────
const _lastRefreshTime = new Map(); // referer -> timestamp
const _autoOpenedTabs = new Map();  // tabId -> referer
const REFRESH_COOLDOWN = 30000;     // 30 seconds cooldown per referer

async function checkAndRefreshFailedDownload(newUrl, cookies, referer) {
  try {
    const data = await getStatus();
    if (!data || !data.downloads) return false;
    
    let newUrlObj = null;
    try { newUrlObj = new URL(newUrl); } catch (_) { return false; }
    
    for (const item of data.downloads) {
      const isFailed = item.rawStatus === "failed" || item.status === "Failed";
      const lastError = item.lastError || "";
      const isExpired = lastError.includes("403") ||
                        lastError.includes("410") ||
                        lastError.includes("401") ||
                        lastError.toLowerCase().includes("expired") ||
                        lastError.toLowerCase().includes("forbidden") ||
                        lastError.toLowerCase().includes("unauthorized");
                        
      if (isFailed && isExpired) {
        const itemReferer = item.referer || "";
        const samePage = itemReferer && referer && (itemReferer.split("?")[0] === referer.split("?")[0]);
        
        let isSameFile = false;
        try {
          const oldUrlObj = new URL(item.url);
          if (oldUrlObj.hostname === newUrlObj.hostname && oldUrlObj.pathname === newUrlObj.pathname) {
            isSameFile = true;
          }
        } catch (_) {}
        
        if (samePage || isSameFile) {
          console.log(`[Ravn Auto-Refresh] Refreshing expired download for ${item.filename} with new link...`);
          const res = await callRavnAPI("/download/refresh", "POST", {
            id: item.id,
            originalUrl: item.url,
            url: newUrl,
            cookies: cookies,
            referer: referer || itemReferer
          });
          
          if (res && res.status === "refreshed") {
            // Close any tab we opened automatically for this referer
            for (const [tabId, ref] of _autoOpenedTabs.entries()) {
              if (ref === itemReferer) {
                _autoOpenedTabs.delete(tabId);
                chrome.tabs.remove(tabId).catch(() => {});
              }
            }
            return true;
          }
        }
      }
    }
  } catch (err) {
    console.error("[Ravn Auto-Refresh] Error in checkAndRefreshFailedDownload:", err);
  }
  return false;
}

async function attemptAutoRefresh(itemId, originalUrl, referer) {
  const now = Date.now();
  const lastTime = _lastRefreshTime.get(referer) || 0;
  if (now - lastTime < REFRESH_COOLDOWN) return;
  _lastRefreshTime.set(referer, now);
  
  try {
    const tabs = await chrome.tabs.query({});
    const matchingTab = tabs.find(t => t.url && t.url.includes(referer));
    
    if (matchingTab) {
      console.log(`[Ravn Auto-Refresh] Reloading active tab ${matchingTab.id} to refresh link for referer: ${referer}`);
      chrome.tabs.reload(matchingTab.id);
    } else {
      console.log(`[Ravn Auto-Refresh] Referer page not open. Creating background tab to refresh link: ${referer}`);
      chrome.tabs.create({ url: referer, active: false }, (newTab) => {
        if (newTab && newTab.id) {
          _autoOpenedTabs.set(newTab.id, referer);
          setTimeout(() => {
            if (_autoOpenedTabs.has(newTab.id)) {
              _autoOpenedTabs.delete(newTab.id);
              chrome.tabs.remove(newTab.id).catch(() => {});
            }
          }, 20000);
        }
      });
    }
  } catch (err) {
    console.error("[Ravn Auto-Refresh] Error in attemptAutoRefresh:", err);
  }
}

// ─── Status Polling ───────────────────────────────────────────────────────────
let _statusPollInterval = null;

function startStatusPolling() {
  if (_statusPollInterval) return;
  _statusPollInterval = setInterval(async () => {
    try {
      const data = await getStatus();
      if (data && data.downloads) {
        for (const item of data.downloads) {
          const isFailed = item.rawStatus === "failed" || item.status === "Failed";
          const lastError = item.lastError || "";
          const isExpired = lastError.includes("403") ||
                            lastError.includes("410") ||
                            lastError.includes("401") ||
                            lastError.toLowerCase().includes("expired") ||
                            lastError.toLowerCase().includes("forbidden") ||
                            lastError.toLowerCase().includes("unauthorized");
                            
          if (isFailed && isExpired) {
            const referer = item.referer || "";
            if (referer) {
              await attemptAutoRefresh(item.id, item.url, referer);
            }
          }
        }
      }
    } catch (_) {
      // App or extension bridge is offline, ignore
    }
  }, 5000);
}

startStatusPolling();
