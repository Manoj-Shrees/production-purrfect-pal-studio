// stream_hook.js — Ravn Stream Grabber (MAIN world)
// ─────────────────────────────────────────────────────────────────────────────
// This file is declared in manifest.json with "world": "MAIN" so it executes
// directly inside the page's own JS context (not the isolated extension world).
// That means we can wrap the real XMLHttpRequest / fetch before ANY page code
// touches them — no <script>-injection tricks, no CSP problems, works on both
// Safari 17+ and Chrome 111+.
//
// Detected stream URLs are relayed to content.js via window.postMessage.
// content.js then forwards them to background.js via chrome.runtime.sendMessage,
// which pushes them to the Ravn Mac app via the local server on port 6543.
// ─────────────────────────────────────────────────────────────────────────────
(function () {
  "use strict";

  if (window.__ravnHookActive) return;
  window.__ravnHookActive = true;

  // ── Filters ────────────────────────────────────────────────────────────────
  const STREAM_RE    = /\.m3u8|\.mpd|\.mp4|\.webm|\.mkv|\.avi|\.mov|\.m4v|\.flv|\.mp3|\.wav|\.aac|\.m4a|\.ogg|\.opus|\.flac/i;
  const STREAM_MIMES = [
    "application/x-mpegurl",
    "application/vnd.apple.mpegurl",
    "application/dash+xml",
  ];
  const AD_RE = /googleads|doubleclick|pagead|adservices|googlesyndication|pubads|\/ad\/|\/ads\/|preroll|midroll|postroll|vast|vpaid|ima3/i;

  function isStreamUrl(url) {
    if (!url) return false;
    const u = url.toLowerCase();
    if (AD_RE.test(u)) return false;
    return STREAM_RE.test(u);
  }

  // ── Relay to content.js via postMessage ────────────────────────────────────
  function relay(url) {
    try {
      window.postMessage({
        __ravn: true,
        action: "streamDetected",
        url: url,
        title: document.title,
        pageUrl: location.href,
      }, "*");
    } catch (_) {}
  }

  // ── Hook XMLHttpRequest ────────────────────────────────────────────────────
  const _XHROpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url) {
    try {
      const full = new URL(url, location.href).href;
      if (isStreamUrl(full)) relay(full);
    } catch (_) {}
    return _XHROpen.apply(this, arguments);
  };

  // ── Hook fetch ─────────────────────────────────────────────────────────────
  const _fetch = window.fetch;
  window.fetch = function (input, init) {
    try {
      const rawUrl =
        typeof input === "string"
          ? input
          : input instanceof Request
          ? input.url
          : String(input);
      const full = new URL(rawUrl, location.href).href;
      if (isStreamUrl(full)) relay(full);
    } catch (_) {}
    return _fetch.apply(this, arguments);
  };

  // ── Watch <video> / <source> for src attribute changes ────────────────────
  function checkEl(el) {
    const src =
      el.currentSrc ||
      el.src ||
      el.getAttribute("src") ||
      "";
    if (src && isStreamUrl(src)) relay(src);
  }

  new MutationObserver((mutations) => {
    for (const m of mutations) {
      m.addedNodes.forEach((n) => {
        if (n.nodeType !== 1) return;
        if (n.tagName === "VIDEO" || n.tagName === "SOURCE") checkEl(n);
        n.querySelectorAll &&
          n.querySelectorAll("video,source").forEach(checkEl);
      });
      if (
        m.type === "attributes" &&
        (m.target.tagName === "VIDEO" || m.target.tagName === "SOURCE")
      ) {
        checkEl(m.target);
      }
    }
  }).observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["src"],
  });

  // Scan elements already in the DOM at injection time
  document.querySelectorAll("video,source").forEach(checkEl);

  // ── Handle blob downloads requested by content.js ─────────────────────────
  window.addEventListener("message", function (e) {
    const d = e.data;
    if (!d || typeof d !== "object" || d.__ravn !== true || d.action !== "fetchBlobInPage") return;
    
    fetch(d.url)
      .then(r => r.blob())
      .then(b => {
        const fr = new FileReader();
        fr.onload = () => {
          window.postMessage({
            __ravn: true,
            action: "blobFetchedInPage",
            requestId: d.requestId,
            dataUrl: fr.result,
            mime: b.type
          }, "*");
        };
        fr.readAsDataURL(b);
      })
      .catch(err => {
        window.postMessage({
          __ravn: true,
          action: "blobFetchedInPage",
          requestId: d.requestId,
          error: err.message || String(err)
        }, "*");
      });
  });
})();
