// Purrfect-pal-studio.Ravn.SafariExtension/Resources/content.js
// Standard WebExtension Content Script for Ravn.
//
// STREAM GRABBER (Safari + Chrome):
//   stream_hook.js runs in "world":"MAIN" (page execution context) and hooks
//   XMLHttpRequest / fetch to detect HLS/DASH streams. It relays detected URLs
//   here via window.postMessage. We forward them to background.js, which sends
// ─────────────────────────────────────────────────────────────────────────────
"use strict";

const extAPI = typeof browser !== "undefined" ? browser : chrome;

// ─── Relay stream URLs from page context (stream_hook.js) → background ───────
const _seenStreamUrls = new Set();
const pendingBlobRequests = new Map();

window.addEventListener("message", (evt) => {
  // Relax the strict window source check to support Safari's cross-world window proxy objects.
  // We rely on the secure and unique __ravn: true and action signatures instead.
  const data = evt.data;
  if (!data || typeof data !== "object" || data.__ravn !== true) return;

  if (data.action === "streamDetected") {
    const { url, title, pageUrl } = data;
    if (!url || _seenStreamUrls.has(url)) return;
    _seenStreamUrls.add(url);

    try {
      chrome.runtime.sendMessage({
        action: "streamDetectedByPage",
        url,
        mime: "application/x-mpegurl",
        title: title || document.title,
        pageUrl: pageUrl || location.href,
      });
    } catch (_) {}
  } else if (data.action === "blobFetchedInPage") {
    const { requestId, dataUrl, mime, error } = data;
    const pending = pendingBlobRequests.get(requestId);
    if (pending) {
      pendingBlobRequests.delete(requestId);
      if (error) {
        pending.reject(new Error(error));
      } else {
        pending.resolve({ dataUrl, mime });
      }
    }
  }
});

// ─── Download link injection ──────────────────────────────────────────────────

const DOWNLOAD_EXTS = new Set([
  "zip","rar","7z","tar","gz","bz2","iso","dmg","pkg",
  "mp4","mkv","avi","mov","m4v","wmv","mp3","flac","wav","aac","m4a",
  "pdf","epub","exe","msi","apk","torrent"
]);

// Removed triggerDownloadInPage as we now route all blobs natively to Ravn.

function isRavnWebsite() {
  try {
    const host = (window.location.hostname || "").toLowerCase();
    const href = (window.location.href || "").toLowerCase();
    
    // Exclude Ravn official website, local dev/staging servers, and portal pages
    if (host === "localhost" || host === "127.0.0.1" || host === "0.0.0.0") return true;
    if (host.includes("ravn") || host.includes("purrfectpal") || host.includes("swiftdm")) return true;
    if (href.includes("ravn") || href.includes("purrfectpal")) return true;
    
    // DOM / metadata safeguards
    if (document.querySelector('meta[name="description"][content*="Ravn"]')) return true;
    if (document.querySelector('meta[name="description"][content*="Download Manager"]')) return true;
    if (document.getElementById("checkoutModalOverlay") || document.getElementById("portalModalOverlay") || document.getElementById("speed-bench")) return true;
    if (document.title && (document.title.includes("Ravn") || document.title.includes("Download Manager"))) return true;
    if (document.querySelector('a[href*="Ravn-Universal.dmg"]') || document.querySelector('a[href*="ravn-chrome-extension"]')) return true;
  } catch (_) {}
  return false;
}

function isDownloadLink(linkOrHref) {
  if (!linkOrHref) return false;
  if (isRavnWebsite()) return false;

  // Exclude Ravn self-binaries or anything marked data-no-ravn
  if (typeof linkOrHref === "object" && typeof linkOrHref.getAttribute === "function") {
    if (linkOrHref.getAttribute("data-no-ravn") === "true" || linkOrHref.getAttribute("data-ravn") === "no") return false;
    if (linkOrHref.classList && (linkOrHref.classList.contains("btn") || linkOrHref.classList.contains("header-dmg-btn") || linkOrHref.classList.contains("nav-link"))) return false;
    if (linkOrHref.closest && linkOrHref.closest(".cta-button-group, header, nav, footer, .modal-box, .benchmark-card, #extensions")) return false;
  }

  const href = typeof linkOrHref === "string" ? linkOrHref : linkOrHref.href;
  if (!href) return false;
  if (href.includes("Ravn-Universal.dmg") || href.includes("ravn-chrome-extension.zip") || href.includes("purrfectpal.studio")) return false;
  if (href.startsWith("magnet:")) return true;

  // 1. Check download attribute filename extension if it's an element
  if (typeof linkOrHref === "object" && typeof linkOrHref.getAttribute === "function") {
    const downloadAttr = linkOrHref.getAttribute("download");
    if (downloadAttr) {
      const ext = downloadAttr.split(".").pop().toLowerCase();
      if (DOWNLOAD_EXTS.has(ext)) return true;
    }
  }

  // 2. Check URL pathname extension
  try {
    const ext = new URL(href).pathname.split(".").pop().toLowerCase();
    return DOWNLOAD_EXTS.has(ext);
  } catch { return false; }
}

// ─── Dispatch helper for Safari & Chrome ──────────────────────────────────────

function dispatchToRavn(url, filename = "") {
  if (!url) return;

  const pageCookies = document.cookie || "";
  const pageReferer = window.location.href || "";

  // 1. Direct Safari Protocol Dispatch via DOM User Gesture Link Click (100% reliable on Safari & Chrome)
  try {
    const encodedUrl = encodeURIComponent(url);
    const encodedFn = filename ? `&filename=${encodeURIComponent(filename)}` : "";
    const encodedCookies = pageCookies ? `&cookies=${encodeURIComponent(pageCookies)}` : "";
    const encodedReferer = pageReferer ? `&referer=${encodeURIComponent(pageReferer)}` : "";
    const schemeUri = `ravn://add?url=${encodedUrl}${encodedFn}${encodedCookies}${encodedReferer}`;

    const triggerLink = document.createElement("a");
    triggerLink.href = schemeUri;
    triggerLink.style.display = "none";
    document.body.appendChild(triggerLink);
    triggerLink.click();
    setTimeout(() => {
      if (triggerLink.parentNode) triggerLink.parentNode.removeChild(triggerLink);
    }, 500);
  } catch (err) {
    console.warn("[Ravn] URL scheme dispatch warning:", err);
  }

  // 2. Send via Extension Message (Native Messaging bridge -> LocalServer :6543)
  try {
    if (extAPI && extAPI.runtime && extAPI.runtime.sendMessage) {
      extAPI.runtime.sendMessage({
        action: "sendURL",
        url: url,
        filename: filename,
        cookies: pageCookies,
        referer: pageReferer
      }).catch(() => {});
    }
  } catch (_) {}

  // 3. Show visual confirmation toast
  const displayName = filename || url.split("/").pop()?.split("?")[0] || "File";
  showRavnToast(`⚡️ Ravn Download Started: ${displayName}`);
}

// ─── Floating Toast Notification ─────────────────────────────────────────────

function showRavnToast(message) {
  let toast = document.getElementById("ravn-ext-toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "ravn-ext-toast";
    Object.assign(toast.style, {
      position: "fixed",
      bottom: "24px",
      right: "24px",
      zIndex: "2147483647",
      padding: "12px 20px",
      borderRadius: "10px",
      background: "rgba(15, 23, 42, 0.92)",
      backdropFilter: "blur(12px)",
      border: "1px solid rgba(99, 102, 241, 0.5)",
      boxShadow: "0 10px 25px rgba(0, 0, 0, 0.4), 0 0 15px rgba(99, 102, 241, 0.3)",
      color: "#ffffff",
      fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, sans-serif",
      fontSize: "13.5px",
      fontWeight: "600",
      letterSpacing: "0.2px",
      display: "flex",
      alignItems: "center",
      gap: "10px",
      transition: "all 0.3s cubic-bezier(0.16, 1, 0.3, 1)",
      transform: "translateY(40px)",
      opacity: "0",
      pointerEvents: "none"
    });
    document.body.appendChild(toast);
  }

  toast.innerHTML = `<span style="font-size: 16px;">⚡️</span><span>${message}</span>`;
  toast.style.transform = "translateY(0)";
  toast.style.opacity = "1";

  if (toast._timer) clearTimeout(toast._timer);
  toast._timer = setTimeout(() => {
    toast.style.transform = "translateY(40px)";
    toast.style.opacity = "0";
  }, 4000);
}

// ─── Automatic Download Link Click Interception (Safari + Chrome) ──────────────

document.addEventListener("click", (e) => {
  // Never intercept if on Ravn's own website or holding modifier keys (Option/Cmd for native download)
  if (isRavnWebsite()) return;
  if (e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;

  const link = e.target.closest("a[href]");
  if (!link) return;

  if (isDownloadLink(link)) {
    // If the click was directly on the injected button, let the button handler handle it
    if (e.target.classList && e.target.classList.contains("ravn-injected-btn")) return;

    e.preventDefault();
    e.stopPropagation();

    const targetUrl = link.href;
    const targetFilename = link.download || "";
    dispatchToRavn(targetUrl, targetFilename);
  }
}, true); // Use capture phase for immediate interception

function injectButtons() {
  // Never inject download buttons on Ravn's own website / checkout pages
  if (isRavnWebsite()) return;

  document.querySelectorAll("a[href]:not([data-ravn])").forEach(link => {
    if (!isDownloadLink(link)) return;
    link.setAttribute("data-ravn", "1");

    const btn = document.createElement("button");
    btn.textContent = "↓ Ravn";
    btn.title = "Download with Ravn Accelerator";
    btn.className = "ravn-injected-btn";
    Object.assign(btn.style, {
      marginLeft: "6px",
      fontSize: "11px",
      fontWeight: "700",
      padding: "2px 8px",
      borderRadius: "5px",
      border: "1px solid #6366f1",
      background: "#eef2ff",
      color: "#4f46e5",
      cursor: "pointer",
      fontFamily: "system-ui, -apple-system, sans-serif",
      lineHeight: "1.4",
      verticalAlign: "middle",
      display: "inline-flex",
      alignItems: "center",
      gap: "2px",
      transition: "all 0.15s ease",
      boxShadow: "0 1px 3px rgba(99, 102, 241, 0.2)",
      zIndex: "9999"
    });

    btn.addEventListener("click", async (e) => {
      e.preventDefault();
      e.stopPropagation();

      btn.textContent = "⚡️ Queuing...";
      btn.style.color = "#d97706";
      btn.style.borderColor = "#fcd34d";
      btn.style.background = "#fffbeb";
      btn.disabled = true;

      const targetUrl = link.href;
      const targetFilename = link.download || "";

      // Handle Blob URLs
      if (targetUrl.startsWith("blob:")) {
        const requestId = Math.random().toString(36).slice(2) + Date.now();

        fetch(targetUrl)
          .then(r => r.blob())
          .then(b => {
            const fr = new FileReader();
            fr.onload = () => {
              const dataUrl = fr.result;
              const resolvedFilename = filenameFromBlob({ type: b.type }, targetFilename);
              dispatchToRavn(dataUrl, resolvedFilename);
              btn.textContent = "✓ Queued";
              btn.style.color = "#16a34a";
              btn.style.borderColor = "#16a34a";
              btn.style.background = "#f0fdf4";
            };
            fr.readAsDataURL(b);
          })
          .catch(() => {
            window.postMessage({
              __ravn: true,
              action: "fetchBlobInPage",
              url: targetUrl,
              filename: targetFilename,
              requestId
            }, "*");
          });
        return;
      }

      // Standard HTTP / HTTPS URLs
      dispatchToRavn(targetUrl, targetFilename);

      btn.textContent = "✓ Queued";
      btn.style.color = "#16a34a";
      btn.style.borderColor = "#16a34a";
      btn.style.background = "#f0fdf4";

      setTimeout(() => {
        btn.textContent = "↓ Ravn";
        btn.style.color = "#4f46e5";
        btn.style.borderColor = "#6366f1";
        btn.style.background = "#eef2ff";
        btn.disabled = false;
      }, 3500);
    });

    link.insertAdjacentElement("afterend", btn);
  });
}

// Initialize on other websites
let _dlObserver = null;

if (!isRavnWebsite()) {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      injectButtons();
      _dlObserver = new MutationObserver(() => injectButtons());
      if (document.body) _dlObserver.observe(document.body, { childList: true, subtree: true });
    });
  } else {
    injectButtons();
    _dlObserver = new MutationObserver(() => injectButtons());
    if (document.body) _dlObserver.observe(document.body, { childList: true, subtree: true });
  }
}

// ─── Video platform detection ─────────────────────────────────────────────────

const VIDEO_PLATFORMS = [
  {
    hosts:   ["youtube.com", "youtu.be"],
    name:    "YouTube",
    icon:    "YT",
    isVideo: u => /youtube\.com\/(watch|shorts\/|live\/)/.test(u) || /youtu\.be\/./.test(u)
  },
  {
    hosts:   ["vimeo.com"],
    name:    "Vimeo",
    icon:    "Vi",
    isVideo: u => /vimeo\.com\/\d/.test(u)
  },
  {
    hosts:   ["dailymotion.com"],
    name:    "Dailymotion",
    icon:    "DM",
    isVideo: u => /dailymotion\.com\/video\//.test(u)
  },
  {
    hosts:   ["twitch.tv"],
    name:    "Twitch",
    icon:    "Tw",
    isVideo: u => /twitch\.tv\/.+\/(videos|clip)\//i.test(u) || /twitch\.tv\/videos\//.test(u)
  },
  {
    hosts:   ["twitter.com", "x.com"],
    name:    "X (Twitter)",
    icon:    "X",
    isVideo: u => /\/(status|i\/status)\/\d/.test(u)
  },
  {
    hosts:   ["tiktok.com"],
    name:    "TikTok",
    icon:    "TT",
    isVideo: u => /@.+\/video\//.test(u) || /tiktok\.com\/t\//.test(u)
  },
  {
    hosts:   ["instagram.com"],
    name:    "Instagram",
    icon:    "IG",
    isVideo: u => /\/(p|reel|tv)\//.test(u)
  },
  {
    hosts:   ["reddit.com"],
    name:    "Reddit",
    icon:    "Re",
    isVideo: u => /reddit\.com\/r\/.+\/comments\//.test(u)
  },
  {
    hosts:   ["facebook.com"],
    name:    "Facebook",
    icon:    "FB",
    isVideo: u => /facebook\.com\/(watch|videos|\?v=)/.test(u) || /facebook\.com\/.+\/videos\//.test(u)
  },
  {
    hosts:   ["bilibili.com"],
    name:    "Bilibili",
    icon:    "BL",
    isVideo: u => /bilibili\.com\/(video|bangumi)/.test(u)
  },
  {
    hosts:   ["soundcloud.com"],
    name:    "SoundCloud",
    icon:    "SC",
    isVideo: u => /soundcloud\.com\/.+\/.+/.test(u) &&
                  !/soundcloud\.com\/(discover|feed|upload|charts)/.test(u)
  },
  {
    hosts:   ["nicovideo.jp"],
    name:    "Niconico",
    icon:    "Ni",
    isVideo: u => /nicovideo\.jp\/watch\//.test(u)
  },
  {
    hosts:   ["rumble.com"],
    name:    "Rumble",
    icon:    "Ru",
    isVideo: u => /rumble\.com\/v/.test(u)
  },
  {
    hosts:   ["odysee.com"],
    name:    "Odysee",
    icon:    "Od",
    isVideo: u => /odysee\.com\/.+\//.test(u)
  }
];

function detectVideoPage() {
  const hostname = location.hostname.replace(/^www\./, "");
  const platform = VIDEO_PLATFORMS.find(p =>
    p.hosts.some(h => hostname === h || hostname.endsWith("." + h))
  );
  if (!platform || !platform.isVideo(location.href)) return null;

  return {
    platform: platform.name,
    icon:     platform.icon,
    url:      location.href,
    title: document.title
      .replace(/\s*[-|–—]\s*(YouTube|Vimeo|TikTok|Twitter|X|Instagram|Reddit|Facebook|Bilibili|Twitch|Dailymotion|SoundCloud|Niconico|Rumble|Odysee).*$/i, "")
      .trim(),
    isAudioOnly: platform.name === "SoundCloud"
  };
}

let _reportTimer   = null;
let _lastReportUrl = "";
const REPORT_DEBOUNCE_MS = 600;

function scheduleReportVideoPage() {
  if (_reportTimer !== null) clearTimeout(_reportTimer);
  _reportTimer = setTimeout(() => {
    _reportTimer = null;
    reportVideoPage();
  }, REPORT_DEBOUNCE_MS);
}

function reportVideoPage() {
  const info = detectVideoPage();
  if (!info) return;

  if (info.url === _lastReportUrl && info.title) return;
  if (!info.title) {
    if (_reportTimer === null) {
      _reportTimer = setTimeout(() => { _reportTimer = null; reportVideoPage(); }, 600);
    }
    return;
  }

  _lastReportUrl = info.url;
  try {
    chrome.runtime.sendMessage({ action: "videoPageDetected", ...info });
  } catch (_) {}
}

setTimeout(reportVideoPage, 300);

let _lastHref = location.href;
const _navObserver = new MutationObserver(() => {
  if (location.href !== _lastHref) {
    _lastHref = location.href;
    scheduleReportVideoPage();
  }
});
_navObserver.observe(document.documentElement, { childList: true, subtree: true });

window.addEventListener("beforeunload", () => {
  if (_dlObserver) { _dlObserver.disconnect(); _dlObserver = null; }
  if (_navObserver) { _navObserver.disconnect(); }
  if (_reportTimer !== null) { clearTimeout(_reportTimer); _reportTimer = null; }
}, { once: true });

// ─── Blob URL extraction ──────────────────────────────────────────────────────

const BLOB_SIZE_LIMIT = 80 * 1024 * 1024;

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload  = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("FileReader error: " + reader.error));
    reader.readAsDataURL(blob);
  });
}

function filenameFromBlob(blob, hint) {
  if (hint && hint.trim()) return hint.trim();
  const mime    = blob.type || "application/octet-stream";
  const base    = mime.split(";")[0].trim();
  const ext     = base.split("/")[1] ?? "bin";
  const cleanExt = ext.replace(/^x-/, "").replace(/^vnd\..+\./, "").split(".").pop();
  return "download." + cleanExt;
}

async function fetchBlobAsDataUrl(blobUrl, filenameHint) {
  let response;
  try {
    response = await fetch(blobUrl);
  } catch (err) {
    throw new Error("fetch(blob:) failed: " + err.message);
  }

  if (!response.ok) throw new Error("blob fetch returned " + response.status);

  const blob = await response.blob();
  if (blob.size === 0) throw new Error("blob is empty");

  if (blob.size > BLOB_SIZE_LIMIT) {
    throw new Error(
      `Blob too large (${(blob.size / 1024 / 1024).toFixed(0)} MB > 80 MB limit). ` +
      "Try right-clicking the media element and using Save As."
    );
  }

  const dataUrl  = await blobToDataUrl(blob);
  const filename = filenameFromBlob(blob, filenameHint);
  return { dataUrl, filename };
}

// ─── Message handler ──────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  switch (msg.action) {

    case "scanPage": {
      const urls = [...document.querySelectorAll("a[href]")]
        .map(a => a.href)
        .filter(href => isDownloadLink(href));
      sendResponse({ urls: [...new Set(urls)] });
      break;
    }

    case "getVideoInfo":
      sendResponse({ info: detectVideoPage() });
      break;

    case "fetchBlob": {
      const { url, filename } = msg;
      if (!url || !url.startsWith("blob:")) {
        sendResponse({ error: "Not a blob URL: " + url });
        break;
      }
      
      const requestId = Math.random().toString(36).slice(2) + Date.now();
      let timeoutId = setTimeout(() => {
        const pending = pendingBlobRequests.get(requestId);
        if (pending) {
          pendingBlobRequests.delete(requestId);
          pending.reject(new Error("Timeout fetching blob in page context"));
        }
      }, 15000);

      new Promise((resolve, reject) => {
        pendingBlobRequests.set(requestId, {
          resolve: (val) => { clearTimeout(timeoutId); resolve(val); },
          reject: (err) => { clearTimeout(timeoutId); reject(err); }
        });
        window.postMessage({
          __ravn: true,
          action: "fetchBlobInPage",
          url,
          filename,
          requestId
        }, "*");
      })
      .then(({ dataUrl, mime }) => {
        const resolvedFilename = filenameFromBlob({ type: mime }, filename);
        sendResponse({ dataUrl, filename: resolvedFilename });
      })
      .catch(err => {
        console.error("[Ravn] fetchBlob failed:", err);
        sendResponse({ error: err.message });
      });
      return true; // keep channel open for async response
    }
  }
});
