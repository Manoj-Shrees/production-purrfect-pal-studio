// Purrfect-pal-studio.Ravn.SafariExtension/Resources/content.js
// Standard WebExtension Content Script for Ravn.
//
// STREAM GRABBER (Safari + Chrome):
//   stream_hook.js runs in "world":"MAIN" (page execution context) and hooks
//   XMLHttpRequest / fetch to detect HLS/DASH streams. It relays detected URLs
//   here via window.postMessage. We forward them to background.js, which sends
(function () {
  if (window.__ravnContentInjected) return;
  window.__ravnContentInjected = true;

  "use strict";

  const extAPI = typeof browser !== "undefined" ? browser : chrome;

  // ─── SVG Icons ────────────────────────────────────────────────────────────────
  const RAVN_DOWNLOAD_ICON = `<svg width="11" height="11" viewBox="0 0 16 16" fill="currentColor" style="display:inline-block;vertical-align:-1px;flex-shrink:0;"><path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/><path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"/></svg>`;
  const RAVN_QUEUING_ICON = `<svg width="11" height="11" viewBox="0 0 16 16" fill="currentColor" class="ravn-spin" style="display:inline-block;vertical-align:-1px;flex-shrink:0;"><path d="M8 3a5 5 0 1 0 4.546 2.914.5.5 0 0 1 .908-.417A6 6 0 1 1 8 2v1z"/></svg>`;
  const RAVN_CHECK_ICON = `<svg width="11" height="11" viewBox="0 0 16 16" fill="currentColor" style="display:inline-block;vertical-align:-1px;flex-shrink:0;"><path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/></svg>`;
  const RAVN_VIDEO_DOWNLOAD_ICON = `<svg width="13" height="13" viewBox="0 0 16 16" fill="currentColor" style="display:inline-block;vertical-align:-1.5px;flex-shrink:0;"><path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/><path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"/></svg>`;
  const RAVN_TOAST_ICON = `<svg width="15" height="15" viewBox="0 0 16 16" fill="currentColor" style="display:inline-block;vertical-align:-2px;flex-shrink:0;"><path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/><path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"/></svg>`;

// ─── Cross-browser runtime messaging (Safari WebKit & Chromium MV3) ──────────
function sendToBackground(payload) {
  return new Promise((resolve, reject) => {
    // 1. Safari / Firefox Promise-based API: browser.runtime.sendMessage(payload)
    if (typeof browser !== "undefined" && browser.runtime?.sendMessage) {
      try {
        const p = browser.runtime.sendMessage(payload);
        if (p && typeof p.then === "function") {
          p.then(resolve).catch(reject);
          return;
        }
      } catch (err) {
        // Fall through
      }
    }

    // 2. Chromium callback-based API: chrome.runtime.sendMessage(payload, callback)
    if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
      try {
        chrome.runtime.sendMessage(payload, (response) => {
          const err = chrome.runtime.lastError;
          if (err) {
            reject(new Error(err.message || String(err)));
          } else {
            resolve(response);
          }
        });
        return;
      } catch (err) {
        reject(err);
        return;
      }
    }

    reject(new Error("No extension runtime messaging available"));
  });
}

// ─── Inject Stream Hook into Main Page Context ────────────────────────────────
// Dynamically injects stream_hook.js to ensure reliable interception across
// all browsers (specifically Safari Web Extensions where world: "MAIN" is ignored)
function injectStreamHook() {
  try {
    if (document.getElementById("ravn-stream-hook")) return;
    const target = document.head || document.documentElement;
    if (!target) return;
    const s = document.createElement("script");
    s.id = "ravn-stream-hook";
    s.src = extAPI.runtime.getURL("stream_hook.js");
    s.async = false;
    target.appendChild(s);
    s.onload = () => s.remove();
  } catch (e) {
    // Silently continue if strict CSP blocks external scripts
  }
}
injectStreamHook();
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", injectStreamHook, { once: true });
}

// ─── Relay stream URLs from page context (stream_hook.js) → background ───────
const _seenStreamUrls = new Set();
const pendingBlobRequests = new Map();

window.addEventListener("message", (evt) => {
  // Relax the strict window source check to support Safari's cross-world window proxy objects.
  // We rely on the secure and unique __ravn: true and action signatures instead.
  const data = evt.data;
  if (!data || typeof data !== "object" || data.__ravn !== true) return;

  if (data.action === "streamDetected") {
    const { url, title, pageUrl } = data;
    if (!url || _seenStreamUrls.has(url)) return;
    _seenStreamUrls.add(url);

    sendToBackground({
      action: "streamDetectedByPage",
      url,
      mime: "application/x-mpegurl",
      title: title || document.title,
      pageUrl: pageUrl || location.href,
    }).catch(() => {});
  } else if (data.action === "blobFetchedInPage") {
    const { requestId, dataUrl, mime, error } = data;
    const pending = pendingBlobRequests.get(requestId);
    if (pending) {
      pendingBlobRequests.delete(requestId);
      if (error) {
        pending.reject(new Error(error));
      } else {
        pending.resolve({ dataUrl, mime });
      }
    }
  }
});

// ─── Download link injection ──────────────────────────────────────────────────

const DOWNLOAD_EXTS = new Set([
  "zip","rar","7z","tar","gz","bz2","xz","iso","dmg","pkg",
  "mp4","mkv","avi","mov","m4v","wmv","webm","flv",
  "mp3","flac","wav","aac","m4a","ogg","opus","wma",
  "pdf","epub","djvu","doc","docx","xls","xlsx","ppt","pptx",
  "exe","msi","deb","rpm","apk","ipa","appimage",
  "torrent"
]);

function isRavnWebsite() {
  try {
    const host = (window.location.hostname || "").toLowerCase();
    
    // Only exclude Ravn official domains
    if (
      host === "ravn.purrfectpal.studio" ||
      host === "purrfectpal.studio" ||
      host === "ravn.app" ||
      host.endsWith(".purrfectpal.studio") ||
      host.endsWith(".ravn.app")
    ) {
      return true;
    }

    // Only exclude local Ravn API server on port 6543
    if ((host === "localhost" || host === "127.0.0.1") && window.location.port === "6543") {
      return true;
    }

    // Safeguard: Ravn marketing checkout modal or local speed benchmark
    if (document.getElementById("checkoutModalOverlay") && document.getElementById("speed-bench")) {
      return true;
    }
  } catch (_) {}
  return false;
}

function isDownloadLink(linkOrHref) {
  if (!linkOrHref) return false;
  if (isRavnWebsite()) return false;

  // Exclude Ravn self-binaries or anything marked data-no-ravn
  if (typeof linkOrHref === "object" && typeof linkOrHref.getAttribute === "function") {
    if (linkOrHref.getAttribute("data-no-ravn") === "true" || linkOrHref.getAttribute("data-ravn") === "no") return false;
    if (linkOrHref.classList && (linkOrHref.classList.contains("ravn-injected-btn") || linkOrHref.classList.contains("ravn-float-btn"))) return false;
  }

  const href = typeof linkOrHref === "string" ? linkOrHref : linkOrHref.href;
  if (!href) return false;
  if (href.startsWith("javascript:") || href.startsWith("#")) return false;
  if (href.includes("Ravn-Universal.dmg") || href.includes("ravn-chrome-extension.zip") || href.includes("purrfectpal.studio")) return false;
  if (href.startsWith("magnet:")) return true;

  // 1. Check download attribute filename extension if it's an element
  if (typeof linkOrHref === "object" && typeof linkOrHref.getAttribute === "function") {
    const downloadAttr = linkOrHref.getAttribute("download");
    if (downloadAttr !== null && downloadAttr !== undefined) {
      if (downloadAttr === "") return true;
      const ext = downloadAttr.split(".").pop().toLowerCase();
      if (DOWNLOAD_EXTS.has(ext)) return true;
    }
  }

  // 2. Check URL pathname extension and query parameters
  try {
    const u = new URL(href, window.location.href);
    const pathnameParts = u.pathname.split("/");
    const lastPart = pathnameParts[pathnameParts.length - 1] || "";
    if (lastPart.includes(".")) {
      const ext = lastPart.split(".").pop().toLowerCase();
      if (DOWNLOAD_EXTS.has(ext)) return true;
    }

    for (const val of u.searchParams.values()) {
      if (typeof val === "string" && val.includes(".")) {
        const valExt = val.split(".").pop().toLowerCase();
        if (DOWNLOAD_EXTS.has(valExt)) return true;
      }
    }
  } catch { return false; }

  return false;
}

// ─── Dispatch helper for Safari & Chrome ──────────────────────────────────────

function triggerRavnScheme(url, filename = "", cookies = "", referer = "") {
  try {
    const encoded = encodeURIComponent(url);
    const fn = filename ? `&filename=${encodeURIComponent(filename)}` : "";
    const ck = cookies ? `&cookies=${encodeURIComponent(cookies)}` : "";
    const rf = referer ? `&referer=${encodeURIComponent(referer)}` : "";
    const schemeUrl = `ravn://add?url=${encoded}${fn}${ck}${rf}`;

    const a = document.createElement("a");
    a.href = schemeUrl;
    a.style.display = "none";
    (document.body || document.documentElement).appendChild(a);
    a.click();
    setTimeout(() => {
      if (a.parentNode) a.parentNode.removeChild(a);
    }, 1000);
  } catch (err) {
    console.error("[Ravn] triggerRavnScheme failed:", err);
  }
}

function dispatchToRavn(url, filename = "") {
  if (!url) return;

  // Resolve to fully qualified absolute URL
  let resolvedUrl = url;
  try {
    resolvedUrl = new URL(url, window.location.href).href;
  } catch (_) {}

  const pageCookies = document.cookie || "";
  const pageReferer = window.location.href || "";

  sendToBackground({
    action: "sendURL",
    url: resolvedUrl,
    filename: filename,
    cookies: pageCookies,
    referer: pageReferer
  }).then((response) => {
    if (!response || response.error || response.ok === false) {
      console.warn("[Ravn] Background sendURL returned non-ok, triggering scheme fallback:", response);
      triggerRavnScheme(resolvedUrl, filename, pageCookies, pageReferer);
    }
  }).catch((err) => {
    console.warn("[Ravn] Extension messaging failed, triggering scheme fallback:", err);
    triggerRavnScheme(resolvedUrl, filename, pageCookies, pageReferer);
  });

  // Show visual confirmation toast
  const displayName = filename || resolvedUrl.split("/").pop()?.split("?")[0] || "File";
  showRavnToast(`Ravn Download Started: ${displayName}`);
}

// ─── Floating Toast Notification ─────────────────────────────────────────────

function showRavnToast(message) {
  let toast = document.getElementById("ravn-ext-toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "ravn-ext-toast";
    Object.assign(toast.style, {
      position: "fixed",
      bottom: "24px",
      right: "24px",
      zIndex: "2147483647",
      padding: "12px 20px",
      borderRadius: "10px",
      background: "rgba(15, 23, 42, 0.92)",
      backdropFilter: "blur(12px)",
      WebkitBackdropFilter: "blur(12px)",
      border: "1px solid rgba(99, 102, 241, 0.5)",
      boxShadow: "0 10px 25px rgba(0, 0, 0, 0.4), 0 0 15px rgba(99, 102, 241, 0.3)",
      color: "#ffffff",
      fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, sans-serif",
      fontSize: "13.5px",
      fontWeight: "600",
      letterSpacing: "0.2px",
      display: "flex",
      alignItems: "center",
      gap: "10px",
      transition: "all 0.3s cubic-bezier(0.16, 1, 0.3, 1)",
      transform: "translateY(40px)",
      opacity: "0",
      pointerEvents: "none"
    });
    document.body.appendChild(toast);
  }

  toast.innerHTML = `<span style="display:inline-flex;align-items:center;">${RAVN_TOAST_ICON}</span><span>${message}</span>`;
  toast.style.transform = "translateY(0)";
  toast.style.opacity = "1";

  if (toast._timer) clearTimeout(toast._timer);
  toast._timer = setTimeout(() => {
    toast.style.transform = "translateY(40px)";
    toast.style.opacity = "0";
  }, 4000);
}

// ─── Automatic Download Link Click Interception (Safari + Chrome) ──────────────

document.addEventListener("click", (e) => {
  // Never intercept if on Ravn's own website or holding modifier keys (Option/Cmd for native download)
  if (isRavnWebsite()) return;
  if (e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;

  const link = e.target.closest("a[href]");
  if (!link) return;

  if (isDownloadLink(link)) {
    // If the click was directly on or inside an injected button, let the button handler handle it
    if (e.target.closest && e.target.closest(".ravn-injected-btn, #ravn-video-float-bar")) return;

    e.preventDefault();
    e.stopPropagation();

    const targetUrl = link.href;
    const targetFilename = link.download || "";
    dispatchToRavn(targetUrl, targetFilename);
  }
}, true); // Use capture phase for immediate interception

// ─── Button & Floating Bar Styles ─────────────────────────────────────────────

function injectRavnStyles() {
  if (document.getElementById("ravn-injected-styles")) return;
  const style = document.createElement("style");
  style.id = "ravn-injected-styles";
  style.textContent = `
    .ravn-injected-btn {
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
      gap: 3px !important;
      margin-left: 6px !important;
      margin-right: 3px !important;
      padding: 2px 8px !important;
      font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Roboto, sans-serif !important;
      font-size: 11px !important;
      font-weight: 600 !important;
      line-height: 1.4 !important;
      border-radius: 6px !important;
      border: 1px solid rgba(99, 102, 241, 0.45) !important;
      background: rgba(99, 102, 241, 0.09) !important;
      color: #6366f1 !important;
      cursor: pointer !important;
      vertical-align: middle !important;
      transition: all 0.18s cubic-bezier(0.16, 1, 0.3, 1) !important;
      box-shadow: 0 1px 3px rgba(99, 102, 241, 0.15) !important;
      z-index: 9999 !important;
      outline: none !important;
      text-decoration: none !important;
      box-sizing: border-box !important;
      height: 20px !important;
      user-select: none !important;
    }
    .ravn-injected-btn:hover:not(:disabled) {
      background: #6366f1 !important;
      color: #ffffff !important;
      border-color: #6366f1 !important;
      box-shadow: 0 2px 8px rgba(99, 102, 241, 0.45) !important;
      transform: translateY(-1px) scale(1.02) !important;
    }
    .ravn-injected-btn:active:not(:disabled) {
      transform: translateY(0) scale(0.98) !important;
    }
    .ravn-injected-btn.ravn-btn-queuing {
      color: #d97706 !important;
      border-color: rgba(245, 158, 11, 0.55) !important;
      background: rgba(245, 158, 11, 0.14) !important;
      cursor: default !important;
    }
    .ravn-injected-btn.ravn-btn-queued {
      color: #16a34a !important;
      border-color: rgba(22, 163, 74, 0.55) !important;
      background: rgba(22, 163, 74, 0.14) !important;
      cursor: default !important;
    }
    @keyframes ravn-spin-anim {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
    .ravn-spin {
      animation: ravn-spin-anim 0.8s linear infinite !important;
      transform-origin: center center !important;
      display: inline-block !important;
    }
    #ravn-video-float-bar {
      position: fixed !important;
      top: 76px !important;
      right: 24px !important;
      z-index: 2147483646 !important;
      display: flex !important;
      align-items: center !important;
      gap: 8px !important;
      padding: 6px 12px !important;
      border-radius: 12px !important;
      background: rgba(15, 23, 42, 0.90) !important;
      backdrop-filter: blur(16px) saturate(180%) !important;
      -webkit-backdrop-filter: blur(16px) saturate(180%) !important;
      border: 1px solid rgba(99, 102, 241, 0.5) !important;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.45), 0 0 18px rgba(99, 102, 241, 0.25) !important;
      font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", system-ui, sans-serif !important;
      font-size: 12px !important;
      font-weight: 600 !important;
      color: #ffffff !important;
      user-select: none !important;
      animation: ravn-slide-in 0.3s cubic-bezier(0.16, 1, 0.3, 1) !important;
    }
    @keyframes ravn-slide-in {
      from { opacity: 0; transform: translateY(-12px); }
      to { opacity: 1; transform: translateY(0); }
    }
    #ravn-video-grab-btn {
      background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%) !important;
      color: #ffffff !important;
      border: none !important;
      border-radius: 8px !important;
      padding: 6px 13px !important;
      font-size: 12px !important;
      font-weight: 600 !important;
      cursor: pointer !important;
      display: inline-flex !important;
      align-items: center !important;
      gap: 6px !important;
      transition: all 0.16s ease !important;
      box-shadow: 0 2px 8px rgba(99, 102, 241, 0.4) !important;
      outline: none !important;
      font-family: inherit !important;
    }
    #ravn-video-grab-btn:hover:not(:disabled) {
      transform: translateY(-1px) scale(1.02) !important;
      box-shadow: 0 4px 14px rgba(99, 102, 241, 0.6) !important;
    }
    #ravn-video-grab-btn:active:not(:disabled) {
      transform: translateY(0) scale(0.98) !important;
    }
    #ravn-video-close-btn {
      background: transparent !important;
      border: none !important;
      color: rgba(255, 255, 255, 0.55) !important;
      font-size: 18px !important;
      line-height: 1 !important;
      cursor: pointer !important;
      padding: 3px 5px !important;
      border-radius: 6px !important;
      transition: all 0.15s ease !important;
      outline: none !important;
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
    }
    #ravn-video-close-btn:hover {
      color: #ffffff !important;
      background: rgba(255, 255, 255, 0.12) !important;
    }
  `;
  const target = document.head || document.documentElement;
  if (target) target.appendChild(style);
}

// ─── Button Injectors ─────────────────────────────────────────────────────────

function createRavnButton(link) {
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "ravn-injected-btn";
  btn.title = "Download with Ravn Accelerator";
  btn.innerHTML = `${RAVN_DOWNLOAD_ICON}<span>Ravn</span>`;

  btn.addEventListener("click", async (e) => {
    e.preventDefault();
    e.stopPropagation();

    btn.disabled = true;
    btn.classList.remove("ravn-btn-queued");
    btn.classList.add("ravn-btn-queuing");
    btn.innerHTML = `${RAVN_QUEUING_ICON}<span>Queuing...</span>`;

    const targetUrl = link.href?.baseVal || link.href || link.getAttribute("href") || "";
    const targetFilename = link.download || "";

    // Handle Blob URLs
    if (targetUrl.startsWith("blob:")) {
      const requestId = Math.random().toString(36).slice(2) + Date.now();

      fetch(targetUrl)
        .then(r => r.blob())
        .then(b => {
          const fr = new FileReader();
          fr.onload = () => {
            const dataUrl = fr.result;
            const resolvedFilename = filenameFromBlob({ type: b.type }, targetFilename);
            dispatchToRavn(dataUrl, resolvedFilename);
            setSuccessState();
          };
          fr.readAsDataURL(b);
        })
        .catch(() => {
          window.postMessage({
            __ravn: true,
            action: "fetchBlobInPage",
            url: targetUrl,
            filename: targetFilename,
            requestId
          }, "*");
          setSuccessState();
        });
      return;
    }

    // Standard HTTP / HTTPS URLs
    dispatchToRavn(targetUrl, targetFilename);
    setSuccessState();

    function setSuccessState() {
      btn.classList.remove("ravn-btn-queuing");
      btn.classList.add("ravn-btn-queued");
      btn.innerHTML = `${RAVN_CHECK_ICON}<span>Queued</span>`;

      setTimeout(() => {
        btn.classList.remove("ravn-btn-queued", "ravn-btn-queuing");
        btn.innerHTML = `${RAVN_DOWNLOAD_ICON}<span>Ravn</span>`;
        btn.disabled = false;
      }, 3500);
    }
  });

  return btn;
}

function injectButtons() {
  if (isRavnWebsite()) return;
  injectRavnStyles();

  const links = document.querySelectorAll("a[href]:not([data-ravn-injected])");
  links.forEach(link => {
    if (!link || !link.href) return;
    link.setAttribute("data-ravn-injected", "1");
    if (!isDownloadLink(link)) return;

    if (link.nextElementSibling && link.nextElementSibling.classList && link.nextElementSibling.classList.contains("ravn-injected-btn")) {
      return;
    }

    try {
      const btn = createRavnButton(link);
      if (link.parentNode && typeof link.insertAdjacentElement === "function") {
        link.insertAdjacentElement("afterend", btn);
      }
    } catch (_) {}
  });
}

// ─── Floating Video Download Bar ──────────────────────────────────────────────

var _floatBarDismissed = false;

function injectVideoFloatingBar() {
  if (isRavnWebsite() || _floatBarDismissed) return;

  const videoInfo = detectVideoPage();
  const hasVideo = !!document.querySelector("video");

  if (!videoInfo && !hasVideo) {
    const existing = document.getElementById("ravn-video-float-bar");
    if (existing) existing.remove();
    return;
  }

  if (document.getElementById("ravn-video-float-bar")) return;
  injectRavnStyles();

  const bar = document.createElement("div");
  bar.id = "ravn-video-float-bar";

  const platformLabel = videoInfo ? videoInfo.platform : "Video";
  const btn = document.createElement("button");
  btn.type = "button";
  btn.id = "ravn-video-grab-btn";
  btn.innerHTML = `${RAVN_VIDEO_DOWNLOAD_ICON}<span>Download ${platformLabel}</span>`;

  btn.addEventListener("click", () => {
    btn.disabled = true;
    btn.innerHTML = `${RAVN_QUEUING_ICON}<span>Grabbing...</span>`;
    btn.style.background = "#d97706";

    const targetUrl = location.href;
    const targetTitle = document.title || "Video";

    sendToBackground({
      action: "grabVideo",
      url: targetUrl,
      title: targetTitle,
      quality: "best"
    }).then((res) => {
      if (!res || !res.ok) {
        triggerRavnScheme(targetUrl, targetTitle);
      }
    }).catch(() => {
      triggerRavnScheme(targetUrl, targetTitle);
    });

    showRavnToast(`Ravn: Grabbing ${platformLabel} Video`);

    setTimeout(() => {
      btn.innerHTML = `${RAVN_CHECK_ICON}<span>Queued</span>`;
      btn.style.background = "#16a34a";
    }, 800);

    setTimeout(() => {
      btn.innerHTML = `${RAVN_VIDEO_DOWNLOAD_ICON}<span>Download ${platformLabel}</span>`;
      btn.style.background = "linear-gradient(135deg, #6366f1, #4f46e5)";
      btn.disabled = false;
    }, 4000);
  });

  const closeBtn = document.createElement("button");
  closeBtn.type = "button";
  closeBtn.id = "ravn-video-close-btn";
  closeBtn.textContent = "×";
  closeBtn.title = "Dismiss";
  closeBtn.addEventListener("click", () => {
    _floatBarDismissed = true;
    bar.remove();
  });

  bar.appendChild(btn);
  bar.appendChild(closeBtn);
  if (document.body) {
    document.body.appendChild(bar);
  }
}

// ─── Lifecycle & Observers ───────────────────────────────────────────────────

var _injectTimer = null;
function scheduleInject() {
  if (_injectTimer !== null) clearTimeout(_injectTimer);
  _injectTimer = setTimeout(() => {
    _injectTimer = null;
    injectButtons();
    injectVideoFloatingBar();
  }, 200);
}

var _dlObserver = null;
function initRavnInjectors() {
  if (isRavnWebsite()) return;

  injectButtons();
  injectVideoFloatingBar();

  if (!_dlObserver && document.body) {
    _dlObserver = new MutationObserver(() => scheduleInject());
    _dlObserver.observe(document.body, { childList: true, subtree: true });
  }
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initRavnInjectors, { once: true });
} else {
  initRavnInjectors();
}

// ─── Video platform detection ─────────────────────────────────────────────────

const VIDEO_PLATFORMS = [
  {
    hosts:   ["youtube.com", "youtu.be"],
    name:    "YouTube",
    icon:    "YT",
    isVideo: u => /youtube\.com\/(watch|shorts\/|live\/)/.test(u) || /youtu\.be\/./.test(u)
  },
  {
    hosts:   ["vimeo.com"],
    name:    "Vimeo",
    icon:    "Vi",
    isVideo: u => /vimeo\.com\/\d/.test(u)
  },
  {
    hosts:   ["dailymotion.com"],
    name:    "Dailymotion",
    icon:    "DM",
    isVideo: u => /dailymotion\.com\/video\//.test(u)
  },
  {
    hosts:   ["twitch.tv"],
    name:    "Twitch",
    icon:    "Tw",
    isVideo: u => /twitch\.tv\/.+\/(videos|clip)\//i.test(u) || /twitch\.tv\/videos\//.test(u)
  },
  {
    hosts:   ["twitter.com", "x.com"],
    name:    "X (Twitter)",
    icon:    "X",
    isVideo: u => /\/(status|i\/status)\/\d/.test(u)
  },
  {
    hosts:   ["tiktok.com"],
    name:    "TikTok",
    icon:    "TT",
    isVideo: u => /@.+\/video\//.test(u) || /tiktok\.com\/t\//.test(u)
  },
  {
    hosts:   ["instagram.com"],
    name:    "Instagram",
    icon:    "IG",
    isVideo: u => /\/(p|reel|tv)\//.test(u)
  },
  {
    hosts:   ["reddit.com"],
    name:    "Reddit",
    icon:    "Re",
    isVideo: u => /reddit\.com\/r\/.+\/comments\//.test(u)
  },
  {
    hosts:   ["facebook.com"],
    name:    "Facebook",
    icon:    "FB",
    isVideo: u => /facebook\.com\/(watch|videos|\?v=)/.test(u) || /facebook\.com\/.+\/videos\//.test(u)
  },
  {
    hosts:   ["bilibili.com"],
    name:    "Bilibili",
    icon:    "BL",
    isVideo: u => /bilibili\.com\/(video|bangumi)/.test(u)
  },
  {
    hosts:   ["soundcloud.com"],
    name:    "SoundCloud",
    icon:    "SC",
    isVideo: u => /soundcloud\.com\/.+\/.+/.test(u) &&
                  !/soundcloud\.com\/(discover|feed|upload|charts)/.test(u)
  },
  {
    hosts:   ["nicovideo.jp"],
    name:    "Niconico",
    icon:    "Ni",
    isVideo: u => /nicovideo\.jp\/watch\//.test(u)
  },
  {
    hosts:   ["rumble.com"],
    name:    "Rumble",
    icon:    "Ru",
    isVideo: u => /rumble\.com\/v/.test(u)
  },
  {
    hosts:   ["odysee.com"],
    name:    "Odysee",
    icon:    "Od",
    isVideo: u => /odysee\.com\/.+\//.test(u)
  }
];

function detectVideoPage() {
  const hostname = location.hostname.replace(/^www\./, "");
  const platform = VIDEO_PLATFORMS.find(p =>
    p.hosts.some(h => hostname === h || hostname.endsWith("." + h))
  );
  if (!platform || !platform.isVideo(location.href)) return null;

  return {
    platform: platform.name,
    icon:     platform.icon,
    url:      location.href,
    title: document.title
      .replace(/\s*[-|–—]\s*(YouTube|Vimeo|TikTok|Twitter|X|Instagram|Reddit|Facebook|Bilibili|Twitch|Dailymotion|SoundCloud|Niconico|Rumble|Odysee).*$/i, "")
      .trim(),
    isAudioOnly: platform.name === "SoundCloud"
  };
}

var _reportTimer   = null;
var _lastReportUrl = "";
const REPORT_DEBOUNCE_MS = 600;

function scheduleReportVideoPage() {
  if (_reportTimer !== null) clearTimeout(_reportTimer);
  _reportTimer = setTimeout(() => {
    _reportTimer = null;
    reportVideoPage();
  }, REPORT_DEBOUNCE_MS);
}

function reportVideoPage() {
  const info = detectVideoPage();
  if (!info) return;

  if (info.url === _lastReportUrl && info.title) return;
  if (!info.title) {
    if (_reportTimer === null) {
      _reportTimer = setTimeout(() => { _reportTimer = null; reportVideoPage(); }, 600);
    }
    return;
  }

  _lastReportUrl = info.url;
  sendToBackground({ action: "videoPageDetected", ...info }).catch(() => {});
}

setTimeout(reportVideoPage, 300);

var _lastHref = location.href;
var _navObserver = new MutationObserver(() => {
  if (location.href !== _lastHref) {
    _lastHref = location.href;
    _floatBarDismissed = false;
    scheduleReportVideoPage();
    scheduleInject();
  }
});
_navObserver.observe(document.documentElement, { childList: true, subtree: true });

window.addEventListener("beforeunload", () => {
  if (_dlObserver) { _dlObserver.disconnect(); _dlObserver = null; }
  if (_navObserver) { _navObserver.disconnect(); }
  if (_reportTimer !== null) { clearTimeout(_reportTimer); _reportTimer = null; }
  if (_injectTimer !== null) { clearTimeout(_injectTimer); _injectTimer = null; }
  window.__ravnContentInjected = false;
}, { once: true });

// ─── Blob URL extraction ──────────────────────────────────────────────────────

const BLOB_SIZE_LIMIT = 80 * 1024 * 1024;

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload  = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("FileReader error: " + reader.error));
    reader.readAsDataURL(blob);
  });
}

function filenameFromBlob(blob, hint) {
  if (hint && hint.trim()) return hint.trim();
  const mime    = blob.type || "application/octet-stream";
  const base    = mime.split(";")[0].trim();
  const ext     = base.split("/")[1] ?? "bin";
  const cleanExt = ext.replace(/^x-/, "").replace(/^vnd\..+\./, "").split(".").pop();
  return "download." + cleanExt;
}

async function fetchBlobAsDataUrl(blobUrl, filenameHint) {
  let response;
  try {
    response = await fetch(blobUrl);
  } catch (err) {
    throw new Error("fetch(blob:) failed: " + err.message);
  }

  if (!response.ok) throw new Error("blob fetch returned " + response.status);

  const blob = await response.blob();
  if (blob.size === 0) throw new Error("blob is empty");

  if (blob.size > BLOB_SIZE_LIMIT) {
    throw new Error(
      `Blob too large (${(blob.size / 1024 / 1024).toFixed(0)} MB > 80 MB limit). ` +
      "Try right-clicking the media element and using Save As."
    );
  }

  const dataUrl  = await blobToDataUrl(blob);
  const filename = filenameFromBlob(blob, filenameHint);
  return { dataUrl, filename };
}

// ─── Message handler ──────────────────────────────────────────────────────────
extAPI.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  switch (msg.action) {

    case "scanPage": {
      const urls = [...document.querySelectorAll("a[href]")]
        .map(a => a.href)
        .filter(href => isDownloadLink(href));
      sendResponse({ urls: [...new Set(urls)] });
      break;
    }

    case "getVideoInfo":
      sendResponse({ info: detectVideoPage() });
      break;

    case "fetchBlob": {
      const { url, filename } = msg;
      if (!url || !url.startsWith("blob:")) {
        sendResponse({ error: "Not a blob URL: " + url });
        break;
      }
      
      const requestId = Math.random().toString(36).slice(2) + Date.now();
      let timeoutId = setTimeout(() => {
        const pending = pendingBlobRequests.get(requestId);
        if (pending) {
          pendingBlobRequests.delete(requestId);
          pending.reject(new Error("Timeout fetching blob in page context"));
        }
      }, 15000);

      new Promise((resolve, reject) => {
        pendingBlobRequests.set(requestId, {
          resolve: (val) => { clearTimeout(timeoutId); resolve(val); },
          reject: (err) => { clearTimeout(timeoutId); reject(err); }
        });
        window.postMessage({
          __ravn: true,
          action: "fetchBlobInPage",
          url,
          filename,
          requestId
        }, "*");
      })
      .then(({ dataUrl, mime }) => {
        const resolvedFilename = filenameFromBlob({ type: mime }, filename);
        sendResponse({ dataUrl, filename: resolvedFilename });
      })
      .catch(err => {
        console.error("[Ravn] fetchBlob failed:", err);
        sendResponse({ error: err.message });
      });
      return true; // keep channel open for async response
    }
  }
});

})();
