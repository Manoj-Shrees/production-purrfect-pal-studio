// Purrfect-pal-studio.Ravn.SafariExtension/Resources/popup.js
// Platform-Independent WebExtension Popup Script for Ravn.
// Routes all direct HTTP calls through the background worker to ensure robust 
// operation in strictly sandboxed/CORS-restricted environments like Safari.
"use strict";

const extAPI = typeof browser !== "undefined" ? browser : chrome;

// Valid quality values — must match YTDLQuality.rawValue in the Swift app exactly
const VALID_QUALITIES = new Set(["best", "2160p", "1080p", "720p", "480p", "audio"]);

let scannedURLs = [];
let _ytdlpMissing = false;   // tracks yt-dlp availability

document.addEventListener("DOMContentLoaded", () => initialize());

async function initialize() {
  bindTabs();
  bindEvents();
  loadSettings();
  // Run sequentially to prevent dropped local server connections
  await refreshStatus();
  await initVideoSection();
  setInterval(refreshStatus, 5000);
}

// ─── Tab switching ─────────────────────────────────────────────────────────────

function bindTabs() {
  document.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const target = btn.dataset.tab;
      document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
      btn.classList.add("active");
      const panel = document.getElementById("tab-" + target);
      if (panel) panel.classList.add("active");
    });
  });
}

// ─── Events ───────────────────────────────────────────────────────────────────

function bindEvents() {
  document.getElementById("addBtn").addEventListener("click", addURL);
  document.getElementById("scanBtn").addEventListener("click", scanPage);
  document.getElementById("refreshBtn").addEventListener("click", refreshStatus);

  document.getElementById("enabled").addEventListener("change", saveSettings);
  document.getElementById("interceptAll").addEventListener("change", saveSettings);
  document.getElementById("streamGrab").addEventListener("change", saveSettings);
  document.getElementById("blobExtract").addEventListener("change", saveSettings);

  document.getElementById("urlInput").addEventListener("keydown", e => {
    if (e.key === "Enter") addURL();
  });

  document.getElementById("grabBtn").addEventListener("click", () => grabCurrentVideo());
  document.getElementById("grabUrlBtn").addEventListener("click", () => grabManualURL());
  document.getElementById("grabUrlInput").addEventListener("keydown", e => {
    if (e.key === "Enter") grabManualURL();
  });
}

// ─── Connection / stats ───────────────────────────────────────────────────────

async function refreshStatus() {
  const online = await pingRavn();
  setConnectionUI(online);
  if (online) {
    await new Promise(r => setTimeout(r, 80));
    await fetchStats();
  } else {
    clearStats();
  }
}

async function pingRavn() {
  try {
    const res = await extAPI.runtime.sendMessage({ action: "ping" }).catch(() => null);
    return !!res?.ok;
  } catch (_) { return false; }
}

async function fetchStats() {
  try {
    const data = await extAPI.runtime.sendMessage({ action: "status" }).catch(() => null);
    if (!data || data.error) {
      clearStats();
      return;
    }
    const downloads = data.downloads ?? [];

    const activeStatuses = new Set(["Downloading", "Queued", "Retrying"]);
    const activeItems = downloads.filter(d => activeStatuses.has(d.status));

    const totalSpeed = downloads
      .filter(d => d.status === "Downloading")
      .reduce((s, d) => s + (d.speed ?? 0), 0);

    document.getElementById("statActive").textContent = activeItems.length;
    document.getElementById("statTotal").textContent = data.total ?? downloads.length;
    document.getElementById("statSpeed").textContent = formatSpeed(totalSpeed);

    // ── Torrent row ──────────────────────────────────────────────────────────
    const torrentItems = downloads.filter(d =>
      (d.protocol === "torrent" || d.protocol === "magnet") &&
      activeStatuses.has(d.status)
    );

    const torrentRow = document.getElementById("torrentRow");
    const torrentInfo = document.getElementById("torrentInfo");

    if (torrentItems.length > 0) {
      const totalSeeds = torrentItems.reduce((s, d) =>
        s + (d.seeds ?? d.torrentSeeds ?? 0), 0);
      const totalPeers = torrentItems.reduce((s, d) =>
        s + (d.peers ?? d.torrentPeers ?? 0), 0);

      const countLabel = torrentItems.length === 1
        ? "1 active"
        : `${torrentItems.length} active`;

      torrentInfo.innerHTML =
        `${countLabel} · ` +
        `<span class="t-seeds">${totalSeeds} seed${totalSeeds !== 1 ? "s" : ""}</span>` +
        ` · ` +
        `<span class="t-peers">${totalPeers} peer${totalPeers !== 1 ? "s" : ""}</span>`;

      torrentRow.classList.add("visible");
    } else {
      torrentRow.classList.remove("visible");
    }

  } catch (_) { clearStats(); }
}

function setConnectionUI(online) {
  document.getElementById("dot").className = "dot " + (online ? "online" : "offline");
  document.getElementById("statusText").textContent = online ? "Connected" : "Not running";
}

function clearStats() {
  document.getElementById("statActive").textContent = "—";
  document.getElementById("statTotal").textContent = "—";
  document.getElementById("statSpeed").textContent = "—";
  document.getElementById("torrentRow").classList.remove("visible");
}

function formatSpeed(bps) {
  if (!bps || bps <= 0) return "0 B/s";
  if (bps < 1024) return bps.toFixed(0) + " B/s";
  if (bps < 1048576) return (bps / 1024).toFixed(1) + " KB/s";
  return (bps / 1048576).toFixed(1) + " MB/s";
}

// ─── Quick Add ────────────────────────────────────────────────────────────────

async function addURL() {
  const input = document.getElementById("urlInput");
  const url = input.value.trim();
  if (!url) return;
  try {
    const res = await extAPI.runtime.sendMessage({ action: "sendURL", url }).catch(() => null);
    if (res?.ok) {
      input.value = "";
      input.placeholder = "✓ Added to Ravn";
      setTimeout(() => { input.placeholder = "Paste URL or magnet link…"; }, 2000);
    }
  } catch (err) { console.error("[Ravn] addURL:", err); }
}

// ─── Video Grabber ────────────────────────────────────────────────────────────

let currentVideoInfo = null;

async function initVideoSection() {
  setYTDLPWarning(false);
  setVideoDetected(false);
  setManualInputsDisabled(false);

  try {
    const ravnOnline = await pingRavn();
    if (ravnOnline) {
      const ytdlp = await extAPI.runtime.sendMessage({ action: "checkYTDLP" }).catch(() => null);
      _ytdlpMissing = !(ytdlp?.available);
      setYTDLPWarning(_ytdlpMissing);
      setManualInputsDisabled(_ytdlpMissing);
    }

    const [tab] = await extAPI.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;

    if (!tab.url ||
      tab.url.startsWith("chrome") ||
      tab.url.startsWith("about") ||
      tab.url.startsWith("devtools")) {
      return;
    }

    let res;
    try {
      res = await extAPI.tabs.sendMessage(tab.id, { action: "getVideoInfo" }).catch(() => null);
    } catch (_) {
      return; // Silent fail if page content script isn't loaded yet
    }

    if (res?.info) {
      currentVideoInfo = res.info;
      setVideoDetected(true, res.info);
      document.getElementById("videoTabBadge").classList.add("visible");
    }
  } catch (_) {}
}

function setYTDLPWarning(missing) {
  document.getElementById("ytdlpMissing").style.display = missing ? "" : "none";
}

function setVideoDetected(show, info = null) {
  const card = document.getElementById("videoDetected");
  card.style.display = show ? "" : "none";
  if (show && info) {
    document.getElementById("videoPlatformBadge").textContent = info.icon ?? "▶";
    document.getElementById("videoTitle").textContent = info.title ?? info.url;
  }
}

function setManualInputsDisabled(_disabled) {
  document.getElementById("grabUrlInput").disabled = false;
  document.getElementById("grabUrlBtn").disabled = false;
  document.getElementById("manualQualitySelect").disabled = false;
  document.getElementById("grabUrlInput").placeholder = "Paste video page URL…";
}

async function grabCurrentVideo() {
  if (!currentVideoInfo) return;
  const quality = sanitiseQuality(document.getElementById("qualitySelect").value);
  const btn = document.getElementById("grabBtn");
  btn.textContent = "Starting…";
  btn.disabled = true;
  try {
    const res = await extAPI.runtime.sendMessage({
      action: "grabVideo",
      url: currentVideoInfo.url,
      title: currentVideoInfo.title,
      quality
    }).catch(() => null);
    if (res?.ok) {
      btn.textContent = "✓ Queued";
      btn.classList.add("queued");
      setTimeout(() => {
        btn.textContent = "↓ Grab";
        btn.classList.remove("queued");
        btn.disabled = false;
      }, 2500);
    } else {
      btn.textContent = "Failed";
      btn.disabled = false;
    }
  } catch (err) {
    console.error("[Ravn] grabCurrentVideo:", err);
    btn.textContent = "↓ Grab";
    btn.disabled = false;
  }
}

async function grabManualURL() {
  const input = document.getElementById("grabUrlInput");
  const url = input.value.trim();
  if (!url) return;

  const quality = sanitiseQuality(document.getElementById("manualQualitySelect").value);
  const btn = document.getElementById("grabUrlBtn");
  btn.textContent = "…";
  btn.disabled = true;

  try {
    const res = await extAPI.runtime.sendMessage({
      action: "grabVideo",
      url,
      title: "",
      quality
    }).catch(() => null);
    if (res?.ok) {
      input.value = "";
      btn.textContent = "✓";
      setTimeout(() => { btn.textContent = "Grab"; btn.disabled = false; }, 2000);
    } else {
      btn.textContent = "Grab";
      btn.disabled = false;
    }
  } catch (err) {
    console.error("[Ravn] grabManualURL:", err);
    btn.textContent = "Grab";
    btn.disabled = false;
  }
}

function sanitiseQuality(q) {
  return VALID_QUALITIES.has(q) ? q : "best";
}

// ─── Page scan ────────────────────────────────────────────────────────────────

async function scanPage() {
  const list = document.getElementById("downloadsList");
  list.innerHTML = '<div class="empty">Scanning…</div>';
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab?.id || !tab.url ||
      tab.url.startsWith("chrome") ||
      tab.url.startsWith("about") ||
      tab.url.startsWith("devtools")) {
      list.innerHTML = '<div class="empty">Cannot scan this page type</div>';
      return;
    }

    const res = await chrome.tabs.sendMessage(tab.id, { action: "scanPage" });
    const urls = res?.urls ?? [];
    scannedURLs = urls;

    if (urls.length === 0) {
      list.innerHTML = '<div class="empty">No downloadable links found</div>';
      return;
    }

    list.innerHTML = "";
    urls.slice(0, 12).forEach((url, i) => {
      let name = "", host = "";
      try {
        const u = new URL(url);
        name = u.pathname.split("/").pop().split("?")[0] || u.hostname;
        host = u.hostname;
      } catch (_) { name = url; }

      const row = document.createElement("div");
      row.className = "dl-item";

      const info = document.createElement("div");
      info.className = "dl-info";

      const nameEl = document.createElement("div");
      nameEl.className = "dl-name";
      nameEl.textContent = name;

      const hostEl = document.createElement("div");
      hostEl.className = "dl-host";
      hostEl.textContent = host;

      const btn = document.createElement("button");
      btn.className = "btn-icon";
      btn.textContent = "↓";
      btn.title = "Download with Ravn";
      btn.addEventListener("click", () => {
        chrome.runtime.sendMessage({ action: "sendURL", url: scannedURLs[i] });
        btn.textContent = "✓";
        btn.classList.add("queued");
      });

      info.append(nameEl, hostEl);
      row.append(info, btn);
      list.appendChild(row);
    });

    if (urls.length > 12) {
      const more = document.createElement("div");
      more.className = "empty";
      more.textContent = `+${urls.length - 12} more`;
      list.appendChild(more);
    }
  } catch (_) {
    list.innerHTML = '<div class="empty">Could not scan — reload the page</div>';
  }
}

// ─── Settings ─────────────────────────────────────────────────────────────────

function loadSettings() {
  chrome.storage.sync.get(["settings"], result => {
    const s = result.settings ?? {
      enabled: true, interceptAll: false, streamGrab: true, blobExtract: true
    };
    document.getElementById("enabled").checked = s.enabled ?? true;
    document.getElementById("interceptAll").checked = s.interceptAll ?? false;
    document.getElementById("streamGrab").checked = s.streamGrab ?? true;
    document.getElementById("blobExtract").checked = s.blobExtract ?? true;
  });
}

function saveSettings() {
  const settings = {
    enabled: document.getElementById("enabled").checked,
    interceptAll: document.getElementById("interceptAll").checked,
    streamGrab: document.getElementById("streamGrab").checked,
    blobExtract: document.getElementById("blobExtract").checked,
  };
  chrome.storage.sync.set({ settings }, () => {
    try {
      chrome.runtime.sendMessage({ action: "updateSettings", settings });
    } catch (_) {}
  });
}
